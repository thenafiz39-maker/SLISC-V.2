import { SchoolEvent, GalleryImage, AdmissionGradeInfo } from './types';

export const CORE_INFO = {
  schoolName: "Southern Lights International School and College",
  acronym: "SLISC",
  slogan: "Nurturing Minds, Inspiring Futures, Empowering Citizens",
  location: "12/B Katalgong, Road# 2, Panchlaish, Chattogram, Bangladesh",
  locationDirections: "Beautifully situated at Katalgong Road# 2 in Panchlaish, Chattogram, providing a secure, high-quality noise-free campus environment.",
  landmark: "Katalgong Road# 2",
  contacts: {
    hotline: "01601-445665",
    campusSec: "+880 1711-098765",
    landline: "+88 031-654321",
    email: "slisc.ctg@gmail.com",
    infoEmail: "slisc.ctg@gmail.com",
    officeHours: "Sunday to Thursday: 8:00 AM - 2:30 PM, Saturday (Inquiry Desk only): 9:00 AM - 1:00 PM"
  },
  socials: {
    facebook: "https://www.facebook.com/SouthernLightsInternationalSchoolAndCollege/",
    facebookPhotos: "https://www.facebook.com/SouthernLightsInternationalSchoolAndCollege/photos",
    linkedin: "https://linkedin.com/school/slisc",
    youtube: "https://youtube.com/c/slisc_edu",
    instagram: "https://www.instagram.com/slisc.ctg/"
  }
};

export const CHOOSE_US_HIGHLIGHTS = [
  {
    id: "global-curriculum",
    title: "Dual Curriculum Path",
    description: "Offering world-class Pearson Edexcel (O & A Levels) alongside the National Curriculum English Version, allowing students to tailor their future global or domestic aspirations.",
    icon: "GraduationCap"
  },
  {
    id: "prime-location",
    title: "Safe & Accessible Location",
    description: "Nestled in Panchlaish, near Parkview Hospital. A quiet residential area with dual-gate security, complete CCTV coverage, and safe transportation services.",
    icon: "MapPin"
  },
  {
    id: "interactive-labs",
    title: "Innovative STEM Facilities",
    description: "Equipped with state-of-the-art physics, chemistry, biology, and computer labs supporting advanced real-world digital literacy.",
    icon: "FlaskConical"
  },
  {
    id: "holistic-focus",
    title: "Holistic Development",
    description: "Extensive co-curricular choices including Public Speaking, Robotics, Chess Club, Football Academy, and Art classes to unleash student potentials.",
    icon: "Award"
  },
  {
    id: "expert-educators",
    title: "Trained & Caring Faculty",
    description: "Our instructors are internationally certified, undergoing weekly pedagogical workshops, maintaining a nurturing student-teacher ratio of 15:1.",
    icon: "Users"
  },
  {
    id: "modern-amenities",
    title: "Air-Conditioned Classrooms",
    description: "Fully air-conditioned, multimedia-enabled classrooms supporting modern visual aids, smart boards, and sterile, clean ventilation environments.",
    icon: "Tv"
  }
];

export const ADMISSION_GRADES: AdmissionGradeInfo[] = [
  {
    grade: "Playgroup & Nursery",
    ageGroup: "3 - 4.5 Years",
    curriculum: "EYFS (Early Years Foundation Stage - UK Framework)",
    feesEstimation: "8,500 BDT / month",
    classTimings: "8:15 AM - 11:30 AM",
    subjects: ["Sensory Development", "Basic Numeracy", "Phonics & Storytelling", "Arts & Motor Skills", "Social Etiquette"]
  },
  {
    grade: "Kindergarten (KG I & KG II)",
    ageGroup: "4.5 - 6 Years",
    curriculum: "Pearson Pre-Primary International curriculum",
    feesEstimation: "9,000 BDT / month",
    classTimings: "8:15 AM - 12:30 PM",
    subjects: ["English Phonics", "Primary Math", "General Knowledge & Nature Study", "Art & Craft", "Physical Activity"]
  },
  {
    grade: "Junior School (Class 1 to 5)",
    ageGroup: "6 - 11 Years",
    curriculum: "Pearson Edexcel Primary iPrimary Curriculum / National Curriculum English Version",
    feesEstimation: "10,500 BDT / month",
    classTimings: "8:00 AM - 1:45 PM",
    subjects: ["English Language & Literature", "Mathematics", "Science (General)", "Bangladesh & Global Studies", "ICT Starter", "Art / Music", "Physical Education"]
  },
  {
    grade: "Middle School (Class 6 to 8)",
    ageGroup: "11 - 14 Years",
    curriculum: "Pearson Edexcel iLowerSecondary / National Curriculum English Version",
    feesEstimation: "11,500 BDT / month",
    classTimings: "8:00 AM - 2:15 PM",
    subjects: ["English Language & Literature", "Mathematics", "Combined Science", "Global Citizenship", "History & Geography", "Information Technology", "Bengali Literature"]
  },
  {
    grade: "O Level / Secondary (Class 9 & 10)",
    ageGroup: "14 - 16 Years",
    curriculum: "Pearson Edexcel International GCSE / SSC National Curriculum English Version",
    feesEstimation: "13,500 BDT / month",
    classTimings: "8:00 AM - 2:30 PM",
    subjects: ["Pure Mathematics & General Math", "English Language", "Physics, Chemistry & Biology", "Accounting / Business Studies", "Economics", "Information & Communication Technology", "Bengali"]
  },
  {
    grade: "A Level / College (Class 11 & 12)",
    ageGroup: "16+ Years",
    curriculum: "Pearson Edexcel GCE International A Level / HSC National Curriculum English Version",
    feesEstimation: "15,500 BDT / month",
    classTimings: "8:00 AM - 2:30 PM",
    subjects: ["Advanced Mathematics (Mechanics/Statistics)", "Chemistry & Physics", "Biology", "Economics & Business", "Accounting", "Applied ICT", "General English"]
  }
];

export const EVENTS_DATA: SchoolEvent[] = [
  {
    id: "evt-1",
    title: "SLISC Science & Tech Fiesta 2026",
    date: "28",
    month: "MAY",
    year: "2026",
    time: "9:00 AM - 3:00 PM",
    location: "Main Exhibition Hall & Labs",
    category: "academic",
    description: "Our middle and secondary high-school scientists present over 75 research prototypes, coding demonstrations, and robotics exhibits. Expert educators from science universities in Chottogram will judge the entries.",
    status: "upcoming"
  },
  {
    id: "evt-2",
    title: "Admission Information Day & Open House",
    date: "04",
    month: "JUN",
    year: "2026",
    time: "10:00 AM - 1:00 PM",
    location: "Auditorium & Admin Block",
    category: "admissions",
    description: "Welcome to prospective parents. Met with the Principal and coordinators, experience our smart classrooms first-hand near Parkview Hospital, and learn details of the Edexcel and English Version fee configurations.",
    status: "upcoming"
  },
  {
    id: "evt-3",
    title: "Annual Sports Champions Trophy",
    date: "12",
    month: "FEB",
    year: "2026",
    time: "8:00 AM - 4:00 PM",
    location: "SLISC Sports Complex & Playground",
    category: "sports",
    description: "A wonderful celebration of our students' physical endurance and talent, showing athletic races, inter-house football championships, chess tournament, and karate drills. Red House took the champion overall shield.",
    status: "past"
  },
  {
    id: "evt-4",
    title: "Internship & Career Counselling Workshop",
    date: "15",
    month: "MAR",
    year: "2026",
    time: "11:00 AM - 1:30 PM",
    location: "Seminar Room A",
    category: "academic",
    description: "A detailed session targeting A-level and College students, featuring esteemed alumni sharing insights on global university admissions, IELTS, SAT preps, and choosing the right fields of science versus commerce.",
    status: "past"
  },
  {
    id: "evt-5",
    title: "Rabindra-Nazrul Cultural Evening",
    date: "25",
    month: "JUN",
    year: "2026",
    time: "4:30 PM - 7:00 PM",
    location: "Outdoor Assembly Amphitheatre",
    category: "cultural",
    description: "Students from all sections perform classic dances, poetry recitations, and musical plays to commemorate our richest cultural pioneers in of Chittagong. High tea will be served.",
    status: "upcoming"
  }
];

export const GALLERY_DATA: GalleryImage[] = [
  {
    id: "gal-1",
    url: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?q=80&w=800&auto=format&fit=crop",
    title: "Junior School Smart Classroom",
    category: "classroom",
    description: "Interactive session using multimedia projectors where students learn STEM geometry concepts on the digitized whiteboards."
  },
  {
    id: "gal-2",
    url: "https://images.unsplash.com/photo-1582719508461-905c673771fd?q=80&w=800&auto=format&fit=crop",
    title: "Advanced Chemistry Laboratory",
    category: "laboratory",
    description: "Our high schoolers conducting O Level experiments inside our state-of-the-art laboratory under complete teacher supervision."
  },
  {
    id: "gal-3",
    url: "https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=800&auto=format&fit=crop",
    title: "SLISC Basketball Court & Team",
    category: "sports",
    description: "An intense practice session for our high school girls basketball division training for the Inter-School Chottogram Championship."
  },
  {
    id: "gal-4",
    url: "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=800&auto=format&fit=crop",
    title: "Digital ICT & Computer Coding Lab",
    category: "classroom",
    description: "Primary children learning scratch programming and basic digital literacy on separate computer setups with fast internet."
  },
  {
    id: "gal-5",
    url: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=800&auto=format&fit=crop",
    title: "Annual Cultural Fest Performance",
    category: "cultural",
    description: "Beautiful theatrical presentation and chorus singing by students on our outdoor assembly stage in the Chottogram campus."
  },
  {
    id: "gal-6",
    url: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=800&auto=format&fit=crop",
    title: "SLISC Resource Library & Silent Area",
    category: "campus",
    description: "A wide catalog of books, scientific publications, O/A Level booklets, and interactive novels available to children."
  },
  {
    id: "gal-7",
    url: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=80&w=800&auto=format&fit=crop",
    title: "Clean Modern Campus Façade",
    category: "campus",
    description: "A glimpse of the clean, secure, multi-storey campus at Panchlaish Residential Area near Parkview Hospital."
  },
  {
    id: "gal-8",
    url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop",
    title: "Active Student Council Debate Meet",
    category: "cultural",
    description: "Student leaders holding their monthly session discussing debate formats and preparing for national contests."
  }
];
