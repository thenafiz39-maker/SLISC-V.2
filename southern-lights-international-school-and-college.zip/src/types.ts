export interface SchoolEvent {
  id: string;
  title: string;
  date: string;
  month: string;
  year: string;
  time: string;
  location: string;
  category: 'academic' | 'sports' | 'cultural' | 'admissions';
  description: string;
  status: 'upcoming' | 'past';
}

export interface GalleryImage {
  id: string;
  url: string;
  title: string;
  category: 'classroom' | 'laboratory' | 'sports' | 'cultural' | 'campus';
  description: string;
}

export interface AdmissionGradeInfo {
  grade: string;
  ageGroup: string;
  curriculum: string;
  feesEstimation: string;
  classTimings: string;
  subjects: string[];
}

export interface InquiryFormData {
  studentName: string;
  dateOfBirth: string;
  gradeInterest: string;
  parentName: string;
  email: string;
  phone: string;
  address: string;
  message: string;
  previousSchool?: string;
}

export interface Teacher {
  id: string;
  name: string;
  role: string;
  qualification: string;
  photoUrl: string;
}
