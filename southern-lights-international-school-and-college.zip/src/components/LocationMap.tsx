import React from 'react';
import { CORE_INFO } from '../data';
import { MapPin, Phone, Mail, Clock, Compass, ExternalLink, Bookmark, ShieldCheck } from 'lucide-react';

interface LocationMapProps {
  lang: 'en' | 'bn';
}

export default function LocationMap({ lang }: LocationMapProps) {
  
  // Quick dial contacts lists
  const contactGroup = lang === 'en' ? [
    { label: "Main Admissions Registry Desk", value: CORE_INFO.contacts.hotline, category: "Hotline" },
    { label: "Accounts & Student Clearance Office", value: CORE_INFO.contacts.landline, category: "Landline" },
    { label: "Emergency Security & Guard Room", value: CORE_INFO.contacts.campusSec, category: "Security" }
  ] : [
    { label: "মূল ভর্তি তথ্য ও রেজিস্ট্রি ডেস্ক", value: CORE_INFO.contacts.hotline, category: "হটলাইন" },
    { label: "হিসাব ও ছাত্র ক্লিয়ারেন্স অফিস", value: CORE_INFO.contacts.landline, category: "ল্যান্ডলাইন" },
    { label: "জরুরি নিরাপত্তা ও গার্ড রুম", value: CORE_INFO.contacts.campusSec, category: "সিকিউরিটি" }
  ];

  return (
    <section id="location-component-root" className="py-20 bg-slate-50 border-t border-slate-100 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div id="location-section-heading" className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-sky-50 text-brand-secondary text-xs uppercase font-extrabold rounded-full tracking-wider mb-3 shadow-xs">
            <Compass className="w-3.5 h-3.5 text-sky-500" />
            {lang === 'en' ? 'Vitals & Campus Blueprint' : 'ভিটালস ও ক্যাম্পাস মানচিত্র'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
            {lang === 'en' ? 'How to Reach Our Campus' : 'আমাদের ক্যাম্পাসে আসার উপায়'}
          </h2>
          <p className="mt-4 text-base text-slate-650 leading-relaxed font-normal">
            {lang === 'en'
              ? 'Located in the premier Panchlaish Residential Area, Chottogram. Securely positioned immediately next to Parkview Hospital for immediate safety and child reassurance.'
              : 'চট্টগ্রামের অতি মনোরম ও নিরাপদ পাঁচলাইশ আবাসিক এলাকায় অবস্থিত। জরুরি চিকিৎসা সুবিধা ও সর্বোচ্চ সুরক্ষার লক্ষ্যে এটি বিখ্যাত পার্কভিউ হাসপাতালের ঠিক পাশেই অবস্থিত।'}
          </p>
        </div>

        {/* 2-Column Map & Directions */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-stretch">
          
          {/* LEFT COLUMN: CONTACT CARDS & VITALS DIRECTORY (5 Columns) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            
            {/* Vitals Summary Card */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-950 relative overflow-hidden shadow-xl">
              <div className="absolute -top-32 -right-32 w-64 h-64 bg-brand-secondary/20 rounded-full light-glow"></div>
              
              <div className="relative z-10 space-y-6">
                <div>
                  <h3 className="font-display font-extrabold text-lg sm:text-xl text-white">
                    {lang === 'en' ? 'SLISC Information Desk' : 'SLISC তথ্য কেন্দ্র ডেস্ক'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {lang === 'en' ? 'Official Landmark Details' : 'অফিসিয়াল ল্যান্ডমার্ক বিবরণী'}
                  </p>
                </div>

                <div className="space-y-4 text-xs sm:text-sm font-normal">
                  {/* Address */}
                  <div className="flex gap-3 items-start">
                    <MapPin className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'Campus Residence' : 'ক্যাম্পাস ঠিকানা'}
                      </span>
                      <p className="text-slate-200 font-semibold mt-1 leading-relaxed">
                        {lang === 'en' ? CORE_INFO.location : 'পাঁচলাইশ আবাসিক এলাকা, চট্টগ্রাম'}
                      </p>
                      <p className="text-[11px] text-slate-400 italic mt-1 leading-relaxed">
                        {lang === 'en' ? CORE_INFO.locationDirections : 'পাঁচলাইশ আবাসিক এলাকা, চট্টগ্রাম (পার্কভিউ হাসপাতালের কাছে)।'}
                      </p>
                    </div>
                  </div>

                  {/* Office Hours */}
                  <div className="flex gap-3 items-start border-t border-slate-800/80 pt-4">
                    <Clock className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'Working Hours' : 'অফিস সময়সূচী'}
                      </span>
                      <p className="text-slate-200 font-semibold mt-1 leading-relaxed">
                        {lang === 'en' ? CORE_INFO.contacts.officeHours : 'রবিবার - বৃহস্পতিবার (সকাল ৮:০০ - বিকাল ৩:৩০ পর্যন্ত)'}
                      </p>
                    </div>
                  </div>

                  {/* General Email */}
                  <div className="flex gap-3 items-start border-t border-slate-800/80 pt-4">
                    <Mail className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'E-Dossier & Emails' : 'অফিসিয়াল ইমেইল'}
                      </span>
                      <p className="text-slate-200 mt-1 font-semibold leading-relaxed hover:text-brand-secondary transition-colors font-mono">
                        <a href={`mailto:${CORE_INFO.contacts.email}`}>{CORE_INFO.contacts.email}</a>
                      </p>
                      <p className="text-slate-200 font-semibold leading-relaxed hover:text-brand-secondary transition-colors text-xs font-mono">
                        <a href={`mailto:${CORE_INFO.contacts.infoEmail}`}>Info: {CORE_INFO.contacts.infoEmail}</a>
                      </p>
                    </div>
                  </div>
                </div>

                {/* External Maps Anchor */}
                <div className="pt-4 border-t border-slate-850">
                  <a
                    href="https://maps.google.com/?q=Parkview+Hospital+Panchlaish+Chottogram"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-slate-800 hover:bg-slate-755 text-brand-secondary py-3.5 rounded-xl font-display font-semibold transition-all duration-300 text-center text-xs shadow-md border border-slate-705 flex items-center justify-center gap-2"
                  >
                    <span>{lang === 'en' ? 'Open in Google Maps' : 'গুগল ম্যাপসে এটি দেখুন'}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Quick Contact dial cards */}
            <div className="bg-white border border-slate-150 rounded-3xl p-6 sm:p-8 shadow-xs">
              <h3 className="font-display font-extrabold text-base sm:text-lg text-slate-900 mb-4 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-650" />
                {lang === 'en' ? 'Administrative Directories' : 'জরুরি যোগাযোগ কর্মকর্তা নির্দেশিকা'}
              </h3>
              
              <div className="space-y-3.5">
                {contactGroup.map((c, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-100 rounded-xl hover:border-slate-300 transition-colors">
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{c.category}</span>
                      <h4 className="font-sans font-bold text-slate-900 text-xs sm:text-sm mt-0.5">{c.label}</h4>
                    </div>
                    <a
                      href={`tel:${c.value}`}
                      className="bg-sky-55 hover:bg-sky-100 text-slate-905 font-bold text-xs px-3.5 py-1.5 rounded-lg border border-sky-100 transition-all text-center select-none cursor-pointer"
                    >
                      {c.value.split(' ')[0]}
                    </a>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: INTERACTIVE VECTOR BLUEPRINT MAP (7 Columns) */}
          <div className="lg:col-span-7">
            <div className="bg-white border border-slate-150 rounded-3xl p-6 sm:p-8 flex flex-col justify-between h-full shadow-xs">
              <div>
                <h3 className="font-display font-extrabold text-slate-900 text-lg sm:text-xl flex items-center gap-2">
                  <Bookmark className="w-5 h-5 text-brand-secondary" />
                  {lang === 'en' ? 'SLISC Street Blueprint' : 'বিদ্যালয়ের ভৌগলিক মানচিত্র (সড়ক বিবরণ)'}
                </h3>
                <p className="text-slate-500 text-xs mt-1 leading-relaxed">
                  {lang === 'en'
                    ? 'Hover or inspect key neighborhood avenues. Located directly along the prestigious Panchlaish primary lane adjacent to Parkview Hospital.'
                    : 'চট্টগ্রাম পাঁচলাইশ আবাসিক এলাকায় অবস্থিত পার্কভিউ হাসপাতালের নিকটবর্তী ক্যাম্পাসের ইন্টারেক্টিভ নকশা চিত্র।'}
                </p>
              </div>

              {/* Vector Blueprint Map Canvas container */}
              <div id="vector-blueprint-map" className="my-6 bg-slate-950 rounded-2xl border border-slate-900 flex items-center justify-center p-4 min-h-76 relative overflow-hidden select-none shadow-inner">
                {/* Stylized Grid SVG representation */}
                <svg viewBox="0 0 400 240" className="w-full h-full text-slate-700 opacity-90">
                  <defs>
                    <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255, 255, 255, 0.05)" strokeWidth="0.5"/>
                    </pattern>
                  </defs>
                  
                  {/* Grid background */}
                  <rect width="100%" height="100%" fill="url(#grid)" />

                  {/* Panchlaish Avenue Streets */}
                  <line x1="10" y1="120" x2="390" y2="120" stroke="#334155" strokeWidth="24" strokeLinecap="round" />
                  <text x="20" y="114" fill="#94a3b8" fontSize="6px" letterSpacing="0.1em" fontWeight="bold">
                    {lang === 'en' ? 'CHOTTOGRAM PANCHLAISH AVE' : 'চট্টগ্রাম পাঁচলাইশ অ্যাভিনিউ'}
                  </text>
                  
                  {/* Road Connecting Parkview Hospital Lane */}
                  <line x1="280" y1="120" x2="280" y2="230" stroke="#334155" strokeWidth="18" strokeLinecap="round" />
                  <text x="248" y="170" fill="#94a3b8" fontSize="5px" transform="rotate(-90 248 170)" fontWeight="bold">
                    {lang === 'en' ? 'PARKVIEW ROAD' : 'পার্কভিউ রোড'}
                  </text>

                  {/* Chottogram Medical Road */}
                  <line x1="120" y1="12" x2="120" y2="120" stroke="#334155" strokeWidth="14" strokeLinecap="round" />
                  <text x="126" y="55" fill="#475569" fontSize="5px" transform="rotate(90 126 55)" fontWeight="bold">
                    {lang === 'en' ? 'MEDICAL OUTPOST RD' : 'মেডিকেল আউটপোস্ট রোড'}
                  </text>

                  {/* LANDMARK: Parkview Hospital Block */}
                  <rect x="298" y="140" width="75" height="50" rx="8" fill="#1e293b" stroke="#ef4444" strokeWidth="1.5" />
                  <text x="335" y="162" fill="#ef4444" fontSize="8px" fontWeight="black" textAnchor="middle">✚</text>
                  <text x="335" y="171" fill="#ffffff" fontSize="4.5px" fontWeight="bold" textAnchor="middle">
                    {lang === 'en' ? 'PARKVIEW' : 'পার্কভিউ'}
                  </text>
                  <text x="335" y="179" fill="#94a3b8" fontSize="4px" textAnchor="middle">
                    {lang === 'en' ? 'HOSPITAL' : 'হাসপাতাল'}
                  </text>

                  {/* LANDMARK: Southern Lights International School & College (SLISC) */}
                  <rect x="150" y="130" width="112" height="75" rx="12" fill="#0f172a" stroke="#0ea5e9" strokeWidth="2.5" />
                  {/* Glow circle */}
                  <circle cx="206" cy="168" r="28" fill="rgba(14, 165, 233, 0.08)" />
                  
                  <text x="206" y="154" fill="#0ea5e9" fontSize="8px" fontWeight="black" textAnchor="middle">🎓 SLISC</text>
                  <text x="206" y="166" fill="#ffffff" fontSize="5px" fontWeight="black" textAnchor="middle">
                    {lang === 'en' ? 'SOUTHERN LIGHTS' : 'সাউদার্ন লাইটস'}
                  </text>
                  <text x="206" y="174" fill="#ffffff" fontSize="4px" textAnchor="middle">
                    {lang === 'en' ? "INT'L SCHOOL & COLLEGE" : "ইন্টারন্যাশনাল স্কুল ও কলেজ"}
                  </text>
                  <text x="206" y="184" fill="#f59e0b" fontSize="4px" fontWeight="bold" textAnchor="middle">
                    {lang === 'en' ? '★ ENROLLING 2026-27' : '★ ভর্তি চলছে ২০২৬-২৭'}
                  </text>
                  
                  {/* Medical Circle Landmark */}
                  <circle cx="120" cy="120" r="14" fill="#334155" />
                  <text x="120" y="122" fill="#e2e8f0" fontSize="4px" fontWeight="bold" textAnchor="middle">
                    {lang === 'en' ? 'ROUNDABOUT' : 'গোলচত্বর'}
                  </text>

                  {/* Beautiful Legend Marker overlay */}
                  <rect x="15" y="15" width="80" height="40" rx="6" fill="rgba(15, 23, 42, 0.9)" stroke="#1e293b" strokeWidth="1" />
                  <circle cx="25" cy="28" r="2.5" fill="#ef4444" />
                  <text x="33" y="30" fill="#94a3b8" fontSize="4px">
                    {lang === 'en' ? 'Parkview Hospital' : 'পার্কভিউ হাসপাতাল'}
                  </text>
                  <circle cx="25" cy="38" r="2.5" fill="#0ea5e9" />
                  <text x="33" y="40" fill="#94a3b8" fontSize="4px">
                    {lang === 'en' ? 'SLISC Main Campus' : 'SLISC মূল ক্যাম্পাস'}
                  </text>
                </svg>

                {/* Legend callout */}
                <div className="absolute top-3 right-3 bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[10px] text-slate-350 font-normal">
                  <span className="font-bold text-white">
                    {lang === 'en' ? 'Security Status:' : 'নিরাপত্তা স্ট্যাটাস:'}
                  </span> {lang === 'en' ? 'Secure Gated Residence' : 'উচ্চ সুরক্ষিত আবাসিক এলাকা'}
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 mt-2 text-xs text-slate-500 leading-relaxed font-normal">
                <strong className="text-slate-950">
                  {lang === 'en' ? 'Access Route Guidance:' : 'ক্যাম্পাসে পৌঁছানোর গাইড:'}
                </strong>{' '}
                {lang === 'en'
                  ? 'Coming from Panchlaish roundabout, proceed straight eastwards along Chottogram Panchlaish Avenue. Take the immediate right turn onto Parkview Road. SLISC secure double gates sit prominently before the entrance to Parkview Hospital. Valet parking is available for inquiring parents.'
                  : 'পাঁচলাইশ গোলচত্বর থেকে পূর্বে পাঁচলাইশ রোডের দিকে সরাসরি এগিয়ে যান। এরপর ডানদিকের টার্ন নিয়ে পার্কভিউ রোডে প্রবেশ করুন। বিশ্বখ্যাত পার্কভিউ হাসপাতালের ঠিক সমুখেই সাউদার্ন লাইটস স্কুল ভবনের প্রধান গেট দেখতে পাবেন। গাড়ি নিয়ে আসা অভিভাবকদের জন্য পার্কিংয়ের বিশেষ সুবিধা রয়েছে।'}
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
