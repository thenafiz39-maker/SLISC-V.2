import React, { useState } from 'react';
import { EVENTS_DATA } from '../data';
import { SchoolEvent } from '../types';
import { Calendar, MapPin, Clock, ArrowRight, X, Sparkles, Filter, Award } from 'lucide-react';

interface EventsSectionProps {
  lang: 'en' | 'bn';
}

export default function EventsSection({ lang }: EventsSectionProps) {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEvent, setSelectedEvent] = useState<SchoolEvent | null>(null);

  // Categories translated
  const categories = lang === 'en' ? [
    { id: 'all', label: 'All Seminars' },
    { id: 'academic', label: 'Academic & STEM' },
    { id: 'sports', label: 'Athletics & Teams' },
    { id: 'cultural', label: 'Cultural Evenings' },
    { id: 'admissions', label: 'Open Houses' }
  ] : [
    { id: 'all', label: 'সব সেমিনার ও সূচি' },
    { id: 'academic', label: 'একাডেমিক ও বিজ্ঞান' },
    { id: 'sports', label: 'খেলাধুলা ও শরীরচর্যা' },
    { id: 'cultural', label: 'সাংস্কৃতিক সন্ধ্যা' },
    { id: 'admissions', label: 'ভর্তি ক্যাম্প ও আলোচনা' }
  ];

  // Filtering logic
  const filteredEvents = EVENTS_DATA.filter(evt => {
    const matchesStatus = evt.status === activeTab;
    const matchesCategory = selectedCategory === 'all' || evt.category === selectedCategory;
    return matchesStatus && matchesCategory;
  });

  // Dynamic Bengali translation dictionary for events
  const getTranslatedEvent = (id: string, field: 'title' | 'desc' | 'location' | 'month') => {
    const translationMap: Record<string, { bnTitle: string; bnDesc: string; bnLocation: string; bnMonth: string }> = {
      'evt-1': {
        bnTitle: "বিজ্ঞান মেলা ও গণিত অলিম্পিয়াড GCE STEM",
        bnDesc: "চট্টগ্রামের পাঁচলাইশ চত্বরে আমাদের শিক্ষার্থীদের বিজ্ঞান প্রকল্প প্রদর্শনী, কোডিং ল্যাব প্রজেক্টস, পদার্থবিজ্ঞান ব্যবহারিক মডেল এবং গণিত অলিম্পিয়াডের বার্ষিক উৎসব প্রতিযোগিতা।",
        bnLocation: "বিজ্ঞান ল্যাব ও প্রধান অডিটোরিয়াম",
        bnMonth: "মে"
      },
      'evt-2': {
        bnTitle: "ভর্তি তথ্য দিবস ও উন্মুক্ত ক্যাম্পাস",
        bnDesc: "সম্মানিত অভিভাবকদের জন্য উন্মুক্ত সেশন। আমাদের অধ্যক্ষ ও কোর্ডিনেটরদের সাথে সরাসরি মতবিনিময় করুন, আমাদের মাল্টিমিডিয়া শ্রেণীকক্ষ পরিদর্শন করুন এবং এডেক্সেল ও ইংলিশ ভার্সন ফি কাঠামো সম্পর্কে বিস্তারিত অবগত হোন (পার্কভিউ হাসপাতালের কাছে)।",
        bnLocation: "বিদ্যালয় অডিটোরিয়াম ও প্রশাসনিক ভবন",
        bnMonth: "জুন"
      },
      'evt-3': {
        bnTitle: "বার্ষিক ক্রীড়া প্রতিযোগিতা চ্যাম্পিয়নস ট্রফি",
        bnDesc: "শিক্ষার্থীদের শারীরিক সুস্থতা ও ক্রীড়াশৈলী প্রদর্শনের গৌরবোজ্জ্বল উৎসব। এতে থাকছে দৌড় প্রতিযোগিতা, আন্তঃহাউস ফুটবল চ্যাম্পিয়নশিপ, দাবা এবং কারাতে প্রদর্শনী। রেড হাউস সামগ্রিক চ্যাম্পিয়ন শিল্ড অর্জন করেছে।",
        bnLocation: "ক্রীড়া কমপ্লেক্স ও বিদ্যালয় খেলার মাঠ",
        bnMonth: "ফেব্রু"
      },
      'evt-4': {
        bnTitle: "ক্যারিয়ার কাউন্সিলিং ও উচ্চতর শিক্ষা কর্মশালা",
        bnDesc: "এ-লেভেল ও কলেজ স্তরের শিক্ষার্থীদের জন্য একটি বিশেষ দিক-নির্দেশনামূলক সেশন। আমাদের সফল প্রাক্তন শিক্ষার্থীদের মাধ্যমে বিশ্বখ্যাত বিশ্ববিদ্যালয়ের ভর্তি প্রক্রিয়া, IELTS ও SAT প্রস্তুতি এবং বিজ্ঞান বনাম কমার্স নির্বাচন নিয়ে আলোচনা।",
        bnLocation: "সেমিনার কক্ষ-এ",
        bnMonth: "মার্চ"
      },
      'evt-5': {
        bnTitle: "রবীন্দ্র-নজরুল সাংস্কৃতিক সন্ধ্যা",
        bnDesc: "আমাদের প্রিয় সাংস্কৃতিক অগ্রণীদের স্মরণে শিক্ষার্থীদের ধ্রুপদী সঙ্গীত পরিবেশনা, কবিতা আবৃত্তি ও চিত্তাকর্ষক নৃত্যানুষ্ঠান। এতে চট্টগ্রামবাসীদের জন্য বিকেলের চায়ের ব্যবস্থা থাকবে।",
        bnLocation: "বহিরাঙ্গন সমাবেশ মুক্তমঞ্চ",
        bnMonth: "জুন"
      }
    };

    const item = translationMap[id];
    if (!item) {
      const orig = EVENTS_DATA.find(e => e.id === id);
      if (!orig) return '';
      return field === 'title' ? orig.title : field === 'desc' ? orig.description : field === 'location' ? orig.location : orig.month;
    }

    if (lang === 'en') {
      const orig = EVENTS_DATA.find(e => e.id === id);
      if (!orig) return '';
      return field === 'title' ? orig.title : field === 'desc' ? orig.description : field === 'location' ? orig.location : orig.month;
    } else {
      return field === 'title' ? item.bnTitle : field === 'desc' ? item.bnDesc : field === 'location' ? item.bnLocation : item.bnMonth;
    }
  };

  return (
    <section id="events-component-root" className="py-20 bg-slate-900 text-white relative overflow-hidden border-t border-slate-950 font-sans">
      
      {/* Background ambient lighting representing the 'Southern Lights' (Aurora aura) */}
      <div className="absolute top-1/4 right-0 w-80 h-80 bg-brand-secondary/15 rounded-full light-glow"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-emerald-500/10 rounded-full light-glow"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-800 text-brand-secondary text-xs uppercase font-extrabold rounded-full tracking-widest mb-3 border border-slate-700">
            <Calendar className="w-3.5 h-3.5 text-brand-secondary" />
            {lang === 'en' ? 'School Circular & Agendas' : 'বিদ্যালয়ের নোটিশ ও প্রাত্যহিক ক্যালেন্ডার'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-white tracking-tight">
            {lang === 'en' ? 'Upcoming Events & Milestones' : 'আসন্ন একাডেমী আলোচনা ও মেগা ইভেন্ট'}
          </h2>
          <p className="mt-4 text-sm sm:text-base text-slate-400 font-normal leading-relaxed">
            {lang === 'en' 
              ? 'Synchronize your schedules with our student activity timelines, admission open days, and STEM Olympiads structured in our Panchlaish, Chottogram campus.'
              : 'চট্টগ্রামের পাঁচলাইশ আবাসিক এলাকায় আমাদের সুরক্ষিত সবুজ প্রাঙ্গণে আয়োজিত নানান সাংস্কৃতিক মেলা, ও/এ লেভেল সেমিনার এবং বিজ্ঞান অলিম্পিয়াডের সময়সূচী দেখে নিন।'}
          </p>
        </div>

        {/* Dual Tab Switcher (Upcoming vs Past) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-800 mb-10">
          
          {/* Status Tab */}
          <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 select-none">
            <button
              id="event-tab-upcoming"
              onClick={() => {
                setActiveTab('upcoming');
                setSelectedCategory('all');
              }}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer ${
                activeTab === 'upcoming'
                  ? 'bg-slate-800 text-brand-secondary shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'Upcoming Schedules' : 'আসন্ন অনুষ্ঠানসমূহ'}
            </button>
            <button
              id="event-tab-past"
              onClick={() => {
                setActiveTab('past');
                setSelectedCategory('all');
              }}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer ${
                activeTab === 'past'
                  ? 'bg-slate-800 text-brand-secondary shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'Historic Glances' : 'অতীতের রঙিন স্মৃতিসমূহ'}
            </button>
          </div>

          {/* Category Dropdowns or Pills */}
          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1.5 sm:pb-0 scrollbar-none">
            <Filter className="w-4 h-4 text-slate-500 shrink-0 hidden md:block" />
            <div className="flex gap-1.5">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  id={`event-cat-${cat.id}`}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-[11px] sm:text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-brand-secondary text-slate-950 font-bold'
                      : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Events Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredEvents.map(evt => (
            <div
              key={evt.id}
              id={`event-card-${evt.id}`}
              className="bg-slate-950/70 border border-slate-800/80 rounded-3xl p-6 hover:border-slate-700 transition-all duration-300 group hover:shadow-cyan-500/5 relative flex flex-col justify-between sm:flex-row gap-6 cursor-pointer"
              onClick={() => setSelectedEvent(evt)}
            >
              
              {/* Date Card Stamp Badge (Left) */}
              <div className="sm:w-20 sm:h-24 bg-gradient-to-tr from-slate-850 to-slate-900 border border-slate-755 p-2 text-center rounded-2xl flex flex-col justify-center items-center shrink-0 shadow-lg group-hover:scale-105 transition-transform duration-300">
                <span className="text-[10px] font-mono font-bold tracking-widest text-slate-400 uppercase leading-none">
                  {getTranslatedEvent(evt.id, 'month')}
                </span>
                <span className="font-display font-black text-2.5xl sm:text-3xl text-brand-secondary my-1 leading-none">
                  {evt.date}
                </span>
                <span className="text-[9px] font-mono font-medium text-slate-550 leading-none">
                  {evt.year}
                </span>
              </div>

              {/* Event Text (Right/Mid) */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <span className="text-[9px] bg-slate-900 border border-slate-750 text-brand-secondary px-2 py-0.5 rounded-md font-bold uppercase tracking-wider">
                      {evt.category === 'academic' && (lang === 'en' ? 'Academic' : 'শিক্ষা')}
                      {evt.category === 'sports' && (lang === 'en' ? 'Sports' : 'ক্রীড়া')}
                      {evt.category === 'cultural' && (lang === 'en' ? 'Cultural' : 'সাংস্কৃতিক')}
                      {evt.category === 'admissions' && (lang === 'en' ? 'Admissions' : 'ভর্তি')}
                    </span>
                    <span className="text-slate-500 text-xs font-mono">•</span>
                    <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-brand-secondary" />
                      {evt.time}
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-lg text-white group-hover:text-brand-secondary transition-colors duration-200 leading-snug">
                    {getTranslatedEvent(evt.id, 'title')}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {getTranslatedEvent(evt.id, 'desc')}
                  </p>
                </div>

                {/* Bottom line trigger link */}
                <div className="mt-4 pt-4 border-t border-slate-850 flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-brand-secondary" />
                    {getTranslatedEvent(evt.id, 'location').split('&')[0]}
                  </span>
                  
                  <button 
                    className="text-xs font-bold text-brand-secondary group-hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    {lang === 'en' ? 'Details' : 'বিস্তারিত'} <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

            </div>
          ))}

          {/* Empty State */}
          {filteredEvents.length === 0 && (
            <div className="col-span-1 md:col-span-2 text-center py-20 bg-slate-950/40 rounded-3xl border border-slate-800">
              <Sparkles className="w-10 h-10 text-slate-700 mx-auto mb-3" />
              <h3 className="text-base font-display font-medium text-slate-350">
                {lang === 'en' ? 'No circular elements matched' : 'কোনো বিশেষ নোটিশ পাওয়া যায়নি'}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                {lang === 'en' ? 'There are no school listings in this tab.' : 'এই বিভাগের জন্য সাম্প্রতিক কোনো বিজ্ঞপ্তি নির্ধারিত হয়নি।'}
              </p>
            </div>
          )}
        </div>

        {/* Modals details popups */}
        {selectedEvent && (
          <div
            id="event-detail-modal"
            className="fixed inset-0 bg-slate-950/85 z-50 flex items-center justify-center p-4 backdrop-blur-md"
            onClick={() => setSelectedEvent(null)}
          >
            <div
              className="bg-slate-900 border border-slate-800 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative animate-scale-in"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button Button */}
              <button
                id="event-modal-close"
                onClick={() => setSelectedEvent(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-slate-850/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>

              {/* Header Colored Block */}
              <div className="bg-gradient-to-r from-slate-950 to-slate-900 p-6 border-b border-slate-800 space-y-2">
                <span className="text-[10px] bg-slate-900 border border-slate-750 text-brand-secondary px-2.5 py-1 rounded-md font-bold uppercase tracking-wider inline-block">
                  {lang === 'en' ? `${selectedEvent.category} Category` : `${selectedEvent.category === 'academic' ? 'শিক্ষা' : selectedEvent.category === 'sports' ? 'শরীর চর্চা' : 'সাধারণ'} বিভাগ`}
                </span>
                <h4 className="font-display font-extrabold text-[#ffffff] text-xl leading-tight">
                  {getTranslatedEvent(selectedEvent.id, 'title')}
                </h4>
              </div>

              {/* Body details */}
              <div className="p-6 space-y-4">
                
                {/* Meta details grids */}
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-black block mb-0.5">{lang === 'en' ? 'Event Date' : 'তারিখ'}</span>
                    <p className="font-semibold text-slate-200">{selectedEvent.date} {getTranslatedEvent(selectedEvent.id, 'month')} {selectedEvent.year}</p>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-black block mb-0.5">{lang === 'en' ? 'Timings' : 'সময়সূচী'}</span>
                    <p className="font-semibold text-slate-200">{selectedEvent.time}</p>
                  </div>
                </div>

                {/* Location blocks */}
                <div className="flex items-start gap-2.5 p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  <MapPin className="w-4 h-4 text-brand-secondary shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-black block">{lang === 'en' ? 'Venue Address' : 'ঘটনাস্থল'}</span>
                    <p className="font-semibold text-slate-200 mt-0.5">{getTranslatedEvent(selectedEvent.id, 'location')}</p>
                    <p className="text-[10px] text-slate-500 italic mt-0.5">
                      {lang === 'en' 
                        ? 'Panchlaish Area, Chottogram (Near Parkview Hospital)'
                        : 'পাঁচলাইশ আবাসিক এলাকা, চট্টগ্রাম (পার্কভিউ হাসপাতালের কাছে)'}
                    </p>
                  </div>
                </div>

                {/* Description details */}
                <div className="text-slate-350 text-xs sm:text-sm leading-relaxed font-normal">
                  <strong className="text-slate-200 block mb-1">{lang === 'en' ? 'Schedule Summary:' : 'বিস্তারিত বিবরণ:'}</strong>
                  {getTranslatedEvent(selectedEvent.id, 'desc')}
                </div>

                {/* Footer status text */}
                <div className="pt-4 border-t border-slate-850 flex justify-between items-center text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full inline-block ${selectedEvent.status === 'upcoming' ? 'bg-brand-secondary animate-pulse' : 'bg-slate-500'}`}></span>
                    <span className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                      {lang === 'en' 
                        ? (selectedEvent.status === 'upcoming' ? 'Status: Active Upcoming' : 'Status: Completed Archive')
                        : (selectedEvent.status === 'upcoming' ? 'অবস্থা: সক্রিয় আসন্ন' : 'অবস্থা: সম্পন্ন')}
                    </span>
                  </div>
                  
                  <button
                    onClick={() => setSelectedEvent(null)}
                    className="bg-brand-secondary hover:bg-sky-500 text-slate-950 px-4 py-2 rounded-lg text-xs font-bold font-display cursor-pointer"
                  >
                    {lang === 'en' ? 'Dismiss View' : 'বন্ধ করুন'}
                  </button>
                </div>

              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
