import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';

interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

interface FAQSectionProps {
  lang: 'en' | 'bn';
}

export default function FAQSection({ lang }: FAQSectionProps) {
  const [openId, setOpenId] = useState<string | null>("faq-1"); // Default pre-opened

  const faqsEn: FaqItem[] = [
    {
      id: "faq-1",
      question: "Are classrooms fully air-conditioned and tech-enabled?",
      answer: "Yes. Every classroom from Playgroup up to GCE A Level/HSC is fully air-conditioned and fitted with multimedia projectors, sterile air filters, and high-contrast digital whiteboards to accommodate smart audiovisual learning."
    },
    {
      id: "faq-2",
      question: "Which curriculums does SLISC offer, and is there Pearson registration?",
      answer: "We offer Pearson Edexcel International Curriculum (O & A Levels) alongside the National Curriculum English Version. SLISC is an officially authorized center, facilitating safe final international board exams inside our secure labs near Parkview Hospital."
    },
    {
      id: "faq-3",
      question: "How do you guarantee student safety near Parkview Hospital's medical lanes?",
      answer: "We are situated slightly inside the Panchlaish quiet residential cul-de-sac. The campus features high security gates, full biometric attendance logs automatically emailed to parents upon entry/exit, 24/7 CCTV surveillance, and specialized security personnel."
    },
    {
      id: "faq-4",
      question: "Do you offer reliable air-conditioned school transport across Chottogram?",
      answer: "Yes, we supervise specialized air-conditioned school transport shuttle buses along designated pathways covering GEC, Halishahar, Nasirabad, Chattogram Cantonment, Khulshi, and Agrabad. Every shuttle maintains a dedicated female conductor."
    },
    {
      id: "faq-5",
      question: "What is the teacher-student ratio, and how are faculty vetted?",
      answer: "To ensure individualized care, we maintain a strict student-to-teacher ratio of 15:1. Every teacher undergoes rigid standard pedagogical training and must maintain certifications from authorized Cambridge or Pearson British council courses."
    }
  ];

  const faqsBn: FaqItem[] = [
    {
      id: "faq-1",
      question: "শ্রেণীকক্ষগুলো কি সম্পূর্ণ শীতাতপ নিয়ন্ত্রিত এবং মাল্টিমিডিয়া সম্বলিত?",
      answer: "হ্যাঁ, প্লেগ্রুপ থেকে ও/এ লেভেল পর্যন্ত আমাদের প্রতিটি ক্লাসরুম সম্পূর্ণ শীতাতপ নিয়ন্ত্রিত। আধুনিক মাল্টিমিডিয়া প্রজেক্টর, বায়ু ফিল্টার এবং ডিজিটাল স্মার্ট সাদা বোর্ড রয়েছে যা অডিও-ভিজ্যুয়াল শিক্ষাকে অনেক সহজ ও সমৃদ্ধ করে তোলে।"
    },
    {
      id: "faq-2",
      question: "SLISC কোন কোন কারিকুলাম অফার করে, এবং এটি কি নিবন্ধিত?",
      answer: "আমরা জাতীয় শিক্ষাক্রমের ইংলিশ ভার্সনের পাশাপাশি আন্তর্জাতিক পিয়ারসন এডেক্সেল কারিকুলাম (ও এবং এ লেভেল) অফার করি। SLISC একটি অফিশিয়াল অনুমোদিত নিবন্ধন কেন্দ্র, যার ফলে পার্কভিউ হাসপাতালের কাছে সুরক্ষিত ল্যাবে চূড়ান্ত বোর্ড পরীক্ষা নেয়া হয়।"
    },
    {
      id: "faq-3",
      question: "পার্কভিউ হাসপাতালের কাছে ব্যস্ত এলাকায় শিক্ষার্থীদের নিরাপত্তা কীভাবে নিশ্চিত করেন?",
      answer: "আমরা পাঁচলাইশ আবাসিক এলাকার মূল সড়ক থেকে কিছুটা ভেতরের গলিতে কোলাহলমুক্ত শান্ত পরিবেশে অবস্থিত। ক্যাম্পাসে রয়েছে উচ্চ নিরাপত্তা গেট, অভিভাবকদের কাছে স্বয়ংক্রিয় বায়োমেট্রিক উপস্থিতি বার্তা, ২৪/৭ সিসিটিভি ক্যামেরা ট্র্যাকিং এবং প্রশিক্ষিত পেশাদার নিরাপত্তা কর্মী।"
    },
    {
      id: "faq-4",
      question: "আপনারা কি চট্টগ্রাম জুড়ে বিশ্বস্ত এসি বাস পরিবহন সেবা প্রদান করেন?",
      answer: "হ্যাঁ, জিইসি, হালিশহর, নাসিরাবাদ, কন্টনমেন্ট, খুলশী, এবং আগ্রাবাদ সংলগ্ন সড়কগুলোতে আমাদের নিজস্ব শীতাতপ নিয়ন্ত্রিত সুসজ্জিত স্কুল বাস সার্ভিস চালু রয়েছে। প্রতিটি বাসে নারী সুপারভাইজার সাহায্যকারী হিসেবে থাকেন।"
    },
    {
      id: "faq-5",
      question: "শিক্ষক ও শিক্ষার্থীর অনুপাত কত এবং শিক্ষকদের কীভাবে যাচাই করা হয়?",
      answer: "ব্যক্তিগত চমৎকার পরিচর্যা নিশ্চিত করতে আমরা ১৫:১ অনুপাত বজায় রাখি। আমাদের প্রত্যেক শিক্ষক কঠোর পেডাগজিক্যাল ট্রেনিংপ্রাপ্ত এবং তারা একাডেমিক যোগ্যতা ছাড়াও পিয়ারসন এডেক্সেল বা ব্রিটিশ কাউন্সিলের বিশেষ ট্রেইনার দ্বারা প্রত্যয়িত।"
    }
  ];

  const faqs = lang === 'en' ? faqsEn : faqsBn;

  const toggleFaq = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faq-component-root" className="py-20 bg-white border-t border-slate-100 font-sans">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-700 text-xs uppercase font-extrabold rounded-full tracking-widest mb-3 shadow-xs">
            <HelpCircle className="w-3.5 h-3.5 text-amber-500" />
            {lang === 'en' ? 'Admissions & Academic FAQs' : 'ভর্তি ও একাডেমিক প্রশ্নোত্তর'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
            {lang === 'en' ? 'Queries & Reassurances' : 'সাধারণ জিজ্ঞাসা ও সমাধান'}
          </h2>
          <p className="mt-3 text-sm text-slate-500 leading-relaxed font-normal">
            {lang === 'en'
              ? 'Answering fundamental questions parents regularly request about Southern Lights International School and College\'s admissions, pathways, and infrastructure in Chittagong.'
              : 'সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ (SLISC) সম্পর্কে অভিভাবকদের পক্ষ থেকে জিজ্ঞেস করা কিছু খুবই গুরুত্বপূর্ণ প্রশ্নের সহজ সমাধান এখানে তুলে ধরা হলো।'}
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {faqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                id={`faq-item-card-${faq.id}`}
                className={`border rounded-2xl transition-all duration-300 overflow-hidden ${
                  isOpen
                    ? 'bg-slate-50 border-slate-300 shadow-md'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Trigger Button */}
                <button
                  id={`faq-trigger-${faq.id}`}
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full flex justify-between items-center px-6 py-5 text-left transition-colors cursor-pointer select-none"
                >
                  <span className="font-display font-extrabold text-sm sm:text-base text-slate-900 pr-4 leading-snug">
                    {faq.question}
                  </span>
                  <span className="shrink-0 p-1.5 rounded-lg bg-slate-100 text-slate-500">
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </span>
                </button>

                {/* Collapsible Content Panels */}
                <div
                  id={`faq-expanded-content-${faq.id}`}
                  className={`transition-all duration-300 ${
                    isOpen ? 'max-h-64 border-t border-slate-150' : 'max-h-0 pointer-events-none'
                  } overflow-hidden`}
                >
                  <p className="px-6 py-5 text-slate-650 text-xs sm:text-sm font-normal leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}

