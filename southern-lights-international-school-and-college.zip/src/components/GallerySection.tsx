import React, { useState, useEffect } from 'react';
import { GALLERY_DATA, CORE_INFO } from '../data';
import { GalleryImage } from '../types';
import { ChevronLeft, ChevronRight, X, Maximize2, Image, Sparkles, ExternalLink } from 'lucide-react';

interface GallerySectionProps {
  lang: 'en' | 'bn';
}

export default function GallerySection({ lang }: GallerySectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Filter images based on state
  const filteredImages = selectedCategory === 'all'
    ? GALLERY_DATA
    : GALLERY_DATA.filter(img => img.category === selectedCategory);

  // List of unique categories for our pill tabs
  const categories = lang === 'en' ? [
    { id: 'all', label: 'All Photos' },
    { id: 'classroom', label: 'Classrooms' },
    { id: 'laboratory', label: 'Science Labs' },
    { id: 'sports', label: 'Sports & Athletics' },
    { id: 'cultural', label: 'Cultural Co-curriculars' },
    { id: 'campus', label: 'Campus Tour' }
  ] : [
    { id: 'all', label: 'সব ছবি' },
    { id: 'classroom', label: 'শ্রেণীকক্ষ' },
    { id: 'laboratory', label: 'বিজ্ঞান ল্যাব' },
    { id: 'sports', label: 'খেলাধুলা ও শরীরচর্চা' },
    { id: 'cultural', label: 'সাংস্কৃতিক মেলবন্ধন' },
    { id: 'campus', label: 'ক্যাম্পাস পরিচিতি' }
  ];

  // Helper dictionary translating picture descriptions dynamically
  const getTranslatedText = (id: string, field: 'title' | 'desc') => {
    const translationsMap: Record<string, { enTitle: string; bnTitle: string; enDesc: string; bnDesc: string }> = {
      'gal-1': {
        enTitle: "Junior School Smart Classroom",
        bnTitle: "জুনিয়র স্কুল স্মার্ট ক্লাস",
        enDesc: "Interactive session using multimedia projectors where students learn STEM geometry concepts on the digitized whiteboards.",
        bnDesc: "মাল্টিমিডিয়া প্রজেক্টর ব্যবহার করে ইন্টারেক্টিভ পাঠ দান, যেখানে শিক্ষার্থীরা জ্যামিতি ও গণিতের নানান ডিজিটাল টুলস শেখে।"
      },
      'gal-2': {
        enTitle: "Advanced Chemistry Laboratory",
        bnTitle: "অত্যাধুনিক রসায়ন বিজ্ঞানাগার",
        enDesc: "Our high schoolers conducting O Level experiments inside our state-of-the-art laboratory under complete teacher supervision.",
        bnDesc: "শিক্ষকদের সার্বক্ষণিক তত্ত্বাবধানে আধুনিক ল্যাবে শিক্ষার্থীদের ব্যবহারিক রসায়ন পরীক্ষা সম্পাদন।"
      },
      'gal-3': {
        enTitle: "SLISC Basketball Court & Team",
        bnTitle: "SLISC বাস্কেটবল কোর্ট ও দল",
        enDesc: "An intense practice session for our high school girls basketball division training for the Inter-School Chottogram Championship.",
        bnDesc: "চট্টগ্রাম আন্তঃস্কুল টুর্নামেন্টের জন্য শিক্ষার্থীদের বাস্কেটবল খেলোয়াড় দলের নিয়মিত অনুশীলন।"
      },
      'gal-4': {
        enTitle: "Digital ICT & Computer Coding Lab",
        bnTitle: "ডিজিটাল আইসিটি ও কম্পিউটার কোডিং ল্যাব",
        enDesc: "Primary children learning scratch programming and basic digital literacy on separate computer setups with fast internet.",
        bnDesc: "আলাদা কম্পিউটারে বাচ্চাদের স্ক্র্যাচ প্রোগ্রামিং শিক্ষা এবং প্রাথমিক কম্পিউটার চালানোর হাতে-কলমে প্রশিক্ষণ।"
      },
      'gal-5': {
        enTitle: "Annual Cultural Fest Performance",
        bnTitle: "বার্ষিক সাংস্কৃতিক উৎসব পরিবেশনা",
        enDesc: "Beautiful theatrical presentation and chorus singing by students on our outdoor assembly stage in the Chottogram campus.",
        bnDesc: "চট্টগ্রাম স্কুল চত্বরে শিক্ষার্থীদের চমৎকার নাট্য পরিবেশনা ও দলীয় লাল-সবুজ সংগীত উৎসব।"
      },
      'gal-6': {
        enTitle: "SLISC Resource Library & Silent Area",
        bnTitle: "SLISC সমৃদ্ধ লাইব্রেরি ও শান্ত রিডিং রুম",
        enDesc: "A wide catalog of books, scientific publications, O/A Level booklets, and interactive novels available to children.",
        bnDesc: "পিয়ারসন এডেক্সেল ও লেভেল / এ লেভেল সহায়ক বই, সায়েন্স জার্নাল ও বিশ্বসাহিত্যের বিশাল সংগ্রহ।"
      },
      'gal-7': {
        enTitle: "Clean Modern Campus Façade",
        bnTitle: "নিরাপদ ও আধুনিক প্রধান ল্যান্ডমার্ক ক্যাম্পাস",
        enDesc: "A glimpse of the clean, secure, multi-storey campus at Panchlaish Residential Area near Parkview Hospital.",
        bnDesc: "চট্টগ্রামের পার্কভিউ হাসপাতালের পাশে সুরম্য ও সার্বক্ষণিক পাহারা বিশিষ্ট পাঁচলাইশ আবাসিক ক্যাম্পাসের দৃশ্য।"
      },
      'gal-8': {
        enTitle: "Active Student Council Debate Meet",
        bnTitle: "স্টুডেন্ট কাউন্সিল বিতর্ক প্রতিযোগিতা",
        enDesc: "Student leaders holding their monthly session discussing debate formats and preparing for national contests.",
        bnDesc: "জাতীয় প্রতিযোগিতায় গৌরব অর্জনের জন্য স্কুল বিতার্কিক দলের নিয়মিত অনুশীলন।"
      }
    };

    const item = translationsMap[id];
    if (!item) return field === 'title' ? "Gallery Photo" : "Campus activity snapshot";
    if (lang === 'en') {
      return field === 'title' ? item.enTitle : item.enDesc;
    } else {
      return field === 'title' ? item.bnTitle : item.bnDesc;
    }
  };

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, filteredImages]);

  const handlePrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(prev => (prev !== null && prev > 0) ? prev - 1 : filteredImages.length - 1);
  };

  const handleNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(prev => (prev !== null && prev < filteredImages.length - 1) ? prev + 1 : 0);
  };

  const selectedImage = lightboxIndex !== null ? filteredImages[lightboxIndex] : null;

  return (
    <section id="gallery-component-root" className="py-20 bg-slate-50 border-t border-slate-100 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div id="gallery-section-heading" className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-sky-50 text-brand-secondary text-xs uppercase font-bold rounded-full tracking-wider mb-3 shadow-xs">
            <Sparkles className="w-3.5 h-3.5" />
            {lang === 'en' ? 'Milestones & Visual Tour' : 'মাইলফলক ও চমৎকার চিত্রশালা'}
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
            {lang === 'en' ? 'Our Vibrant Campus Gallery' : 'আমাদের প্রাণবন্ত ক্যাম্পাস গ্যালারি'}
          </h2>
          <p className="mt-4 text-base text-slate-650 font-normal leading-relaxed">
            {lang === 'en' 
              ? 'Take a look into academic sessions, modern science lab research, and energetic cultural celebrations thriving within SLISC in Chottogram.'
              : 'সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ চট্টগ্রামের প্রাত্যহিক শিক্ষা কার্যক্রম, আধুনিক বিজ্ঞানাগারের গবেষণা এবং সজীব ক্রীড়া ও সাংস্কৃতিক অর্জনের এক ঝলক দেখে নিন।'}
          </p>
        </div>

        {/* Tab Filters */}
        <div 
          id="gallery-tab-filters-container"
          className="flex flex-wrap justify-center items-center gap-2 mb-10 overflow-x-auto pb-2 scrollbar-none"
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              id={`gallery-filter-${cat.id}`}
              onClick={() => {
                setSelectedCategory(cat.id);
                setLightboxIndex(null);
              }}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold tracking-wide transition-all duration-300 transform select-none cursor-pointer border ${
                selectedCategory === cat.id
                  ? 'bg-slate-900 text-brand-secondary border-slate-950 shadow-md scale-102 font-bold'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Image Grid */}
        <div 
          id="gallery-grid"
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 sm:gap-8"
        >
          {filteredImages.map((image, idx) => (
            <div
              key={image.id}
              id={`gallery-card-${image.id}`}
              className="bg-white rounded-2xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 group border border-slate-150 relative cursor-pointer"
              onClick={() => setLightboxIndex(idx)}
            >
              {/* Aspect Ratio Container */}
              <div id={`image-container-${image.id}`} className="aspect-h-3 aspect-w-4 sm:aspect-h-1 sm:aspect-w-1 h-56 overflow-hidden relative">
                <img
                  src={image.url}
                  alt={getTranslatedText(image.id, 'title')}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full bg-brand-secondary text-slate-950 flex items-center justify-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-md">
                    <Maximize2 className="w-4 h-4 font-bold" />
                  </div>
                </div>

                {/* Floating Category Badge */}
                <span className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-slate-200 text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-md border border-slate-700">
                  {image.category === 'classroom' && (lang === 'en' ? 'Classroom' : 'শ্রেণীকক্ষ')}
                  {image.category === 'laboratory' && (lang === 'en' ? 'Laboratory' : 'বিজ্ঞানাগার')}
                  {image.category === 'sports' && (lang === 'en' ? 'Sports' : 'খেলাধুলা')}
                  {image.category === 'cultural' && (lang === 'en' ? 'Cultural' : 'সাংস্কৃতিক')}
                  {image.category === 'campus' && (lang === 'en' ? 'Campus' : 'ক্যাম্পাস')}
                </span>
              </div>

              {/* Card Meta Content */}
              <div className="p-4 border-t border-slate-100">
                <h3 className="font-display font-bold text-sm text-slate-900 line-clamp-1 group-hover:text-cyan-600 transition-colors duration-200">
                  {getTranslatedText(image.id, 'title')}
                </h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {getTranslatedText(image.id, 'desc')}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredImages.length === 0 && (
          <div id="gallery-empty-state" className="text-center py-20 bg-white rounded-2xl border border-slate-200 p-8">
            <Image className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-display font-medium text-slate-950">
              {lang === 'en' ? 'No Photos Listed' : 'কোনো ছবি পাওয়া যায়নি'}
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {lang === 'en' ? 'We are auditing new campus photographs.' : 'আমরা এই শ্রেণীর জন্য নতুন ছবি সংগ্রহ করছি।'}
            </p>
          </div>
        )}

        {/* Interactive Lightbox Backdrop */}
        {lightboxIndex !== null && selectedImage && (
          <div
            id="gallery-lightbox-overlay"
            className="fixed inset-0 bg-slate-950/98 z-50 flex flex-col justify-between p-4 sm:p-6"
            onClick={() => setLightboxIndex(null)}
          >
            {/* Top Lightbox Bar */}
            <div className="flex justify-between items-center w-full z-10 text-white select-none" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400">
                  {lightboxIndex + 1} of {filteredImages.length}
                </span>
                <span className="text-slate-600">|</span>
                <span className="bg-slate-800 text-[10px] text-brand-secondary uppercase font-bold px-2 py-0.5 rounded border border-slate-700">
                  {selectedImage.category}
                </span>
              </div>
              <button
                id="lightbox-close-btn"
                onClick={() => setLightboxIndex(null)}
                className="p-2 sm:p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Lightbox Stage */}
            <div className="flex-1 flex items-center justify-center relative my-4" onClick={(e) => e.stopPropagation()}>
              {/* Prev Trigger Button */}
              <button
                id="lightbox-prev-btn"
                onClick={handlePrev}
                className="absolute left-0 sm:left-4 z-10 p-2.5 sm:p-4 rounded-full bg-slate-900/60 hover:bg-slate-800 border border-slate-800 hover:scale-105 active:scale-95 text-slate-350 hover:text-white transition-all cursor-pointer shadow-lg"
              >
                <ChevronLeft className="w-6 h-6 sm:w-8 h-8" />
              </button>

              {/* High-Res Image Display */}
              <div className="max-w-4xl max-h-[70vh] flex items-center justify-center p-2 relative group-stage select-none">
                <img
                  src={selectedImage.url}
                  alt={getTranslatedText(selectedImage.id, 'title')}
                  referrerPolicy="no-referrer"
                  className="max-w-full max-h-[70vh] object-contain rounded-lg border border-slate-800 shadow-2xl animate-fade-in"
                />
              </div>

              {/* Next Trigger Button */}
              <button
                id="lightbox-next-btn"
                onClick={handleNext}
                className="absolute right-0 sm:right-4 z-10 p-2.5 sm:p-4 rounded-full bg-slate-900/60 hover:bg-slate-800 border border-slate-800 hover:scale-105 active:scale-95 text-slate-350 hover:text-white transition-all cursor-pointer shadow-lg"
              >
                <ChevronRight className="w-6 h-6 sm:w-8 h-8" />
              </button>
            </div>

            {/* Lightbox Metadata Drawer */}
            <div 
              className="max-w-2xl mx-auto text-center pb-4 z-10" 
              onClick={(e) => e.stopPropagation()}
            >
              <h4 className="text-white font-display font-bold text-lg sm:text-xl">
                {getTranslatedText(selectedImage.id, 'title')}
              </h4>
              <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed max-w-lg mx-auto">
                {getTranslatedText(selectedImage.id, 'desc')}
              </p>
            </div>
          </div>
        )}

        {/* Live Facebook Photos Link Banner */}
        <div 
          id="gallery-facebook-cta-banner"
          className="mt-16 p-6 sm:p-10 bg-gradient-to-tr from-slate-900 via-slate-950 to-slate-900 rounded-3xl border border-slate-800 text-center relative overflow-hidden shadow-xl"
        >
          {/* subtle aurora glow inside */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-40 bg-brand-secondary/10 rounded-full light-glow"></div>
          
          <div className="relative z-10 max-w-2xl mx-auto space-y-5">
            <span className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 text-brand-secondary text-[11px] uppercase font-extrabold rounded-md border border-blue-500/20 tracking-wider">
              {lang === 'en' ? 'Facebook Live Chronicle' : 'ফেসবুক লাইভ চিত্রশালা'}
            </span>
            <h3 className="font-display font-black text-xl sm:text-2xl text-white">
              {lang === 'en' ? 'Browse Thousands of Actual School Activity Photos' : 'আমাদের ফেসবুক পৃষ্ঠা থেকে হাজার হাজার বাস্তব ছবির অ্যালবাম দেখুন'}
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm font-normal leading-relaxed">
              {lang === 'en'
                ? 'We continually upload snapshots of daily assemblies, science experiments, sports tournament victories, classroom smiles, and field trips. View our official Facebook Photos stream directly for real-time updates.'
                : 'আমরা প্রতিনিয়ত আমাদের শিক্ষার্থীদের প্রাত্যহিক সমাবেশ, বিজ্ঞান পরীক্ষা, ক্রীড়া প্রতিযোগিতা জয়, বিজ্ঞান মেলা এবং শিক্ষা সফরের প্রকৃত ছবি আপলোড করি। আমাদের অফিশিয়াল ফেসবুক ছবির স্রোতটি সরাসরি দেখুন।'}
            </p>
            <div className="pt-2">
              <a
                href={CORE_INFO.socials.facebookPhotos}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[#1877F2] hover:bg-blue-650 text-white font-display font-bold text-xs sm:text-sm py-3.5 px-8 rounded-xl tracking-wide transition-all transform hover:-translate-y-0.5 shadow-md hover:shadow-blue-500/20 uppercase"
              >
                <span>{lang === 'en' ? 'Visit SLISC Facebook Photo Stream' : 'SLISC ফেসবুক ফটো গ্যালারিতে যান'}</span>
                <ExternalLink className="w-4 h-4 text-white" />
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

