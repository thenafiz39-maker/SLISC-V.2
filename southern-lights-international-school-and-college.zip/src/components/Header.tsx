import React, { useState, useEffect } from 'react';
import { Menu, X, GraduationCap, Phone, Mail, Clock, Languages } from 'lucide-react';
import { CORE_INFO } from '../data';
import { TRANSLATIONS } from '../translations';

interface HeaderProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  lang: 'en' | 'bn';
  setLang: (lang: 'en' | 'bn') => void;
}

export default function Header({ activeSection, onNavigate, lang, setLang }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const t = TRANSLATIONS[lang];

  const navItems = [
    { id: 'home', label: t.navHome },
    { id: 'about', label: t.navAbout },
    { id: 'features', label: t.navWhyChooseUs },
    { id: 'admissions', label: t.navAdmissions },
    { id: 'events', label: t.navEvents },
    { id: 'gallery', label: t.navGallery },
    { id: 'contact', label: t.navContact }
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  const toggleLanguage = () => {
    setLang(lang === 'en' ? 'bn' : 'en');
  };

  return (
    <>
      {/* Top Notification Bar */}
      <div id="top-notification-bar" className="bg-brand-primary text-slate-300 text-xs py-2 px-4 border-b border-slate-800 hidden sm:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-brand-secondary" />
              {lang === 'en' ? 'Sunday to Thursday: 8:00 AM - 2:30 PM' : 'রবিবার থেকে বৃহস্পতিবার: সকাল ৮:০০ - দুপুর ২:৩০'}
            </span>
            <span className="flex items-center gap-1">
              <Mail className="w-3.5 h-3.5 text-brand-secondary" />
              {CORE_INFO.contacts.email}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 font-semibold text-white animate-pulse">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block pointer-events-none"></span>
              {lang === 'en' ? 'Admissions Open (Session 2026-27)' : 'ভর্তি চলছে (সেশন ২০২৬-২৭)'}
            </span>
            <span className="text-slate-400">|</span>
            <a href={`tel:${CORE_INFO.contacts.hotline}`} className="hover:text-white transition-colors flex items-center gap-1 font-medium">
              <Phone className="w-3.5 h-3.5 text-brand-secondary" />
              {lang === 'en' ? 'Hotline' : 'হটলাইন'}: {CORE_INFO.contacts.hotline}
            </a>
          </div>
        </div>
      </div>

      {/* Main Glassmorphic Header */}
      <header
        id="main-app-header"
        className={`sticky top-0 z-40 transition-all duration-300 ${
          scrolled 
            ? 'bg-slate-900/95 backdrop-blur-md shadow-lg border-b border-slate-800' 
            : 'bg-slate-900/90 border-b border-transparent'
        } text-white`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-18 sm:h-20">
            {/* Logo and Name */}
            <div 
              id="header-brand-logo"
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => handleNavClick('home')}
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-gradient-to-tr from-brand-secondary to-brand-accent p-0.5 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-300">
                <div className="w-full h-full bg-slate-900 rounded-[6px] flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-brand-secondary group-hover:text-brand-accent transition-colors duration-300" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-base sm:text-lg tracking-tight leading-none text-white group-hover:text-brand-secondary transition-colors duration-300">
                  {lang === 'en' ? 'SOUTHERN LIGHTS' : 'সাউদার্ন লাইটস'}
                </span>
                <span className="font-sans text-[9px] sm:text-[11px] text-slate-400 font-medium tracking-wide mt-0.5">
                  {lang === 'en' ? 'International School & College · SLISC' : 'ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ • SLISC'}
                </span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav id="desktop-navbar" className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium tracking-wide transition-all duration-300 ${
                      isActive
                        ? 'text-brand-secondary bg-slate-800/65 border border-slate-800'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/30 border border-transparent'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>

            {/* Right Action Button & Language Switcher */}
            <div className="hidden lg:flex items-center gap-3">
              {/* Language Switcher Button */}
              <button
                id="header-language-toggle"
                onClick={toggleLanguage}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 hover:bg-slate-750 hover:text-brand-secondary transition-all"
                title={lang === 'en' ? 'Switch to Bangla' : 'ইংরেজিতে পরিবর্তন করুন'}
              >
                <Languages className="w-4 h-4 text-brand-secondary" />
                <span>{lang === 'en' ? 'বাংলা' : 'EN'}</span>
              </button>

              <button
                id="header-apply-cta"
                onClick={() => handleNavClick('admissions')}
                className="bg-brand-secondary hover:bg-sky-500 text-slate-950 font-display font-semibold text-xs py-2.5 px-4 rounded-lg tracking-wider transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-cyan-500/25 cursor-pointer uppercase"
              >
                {lang === 'en' ? 'Inquire Online' : 'অনলাইন তথ্য ফরম'}
              </button>
            </div>

            {/* Mobile Menu Button & Mini Switcher */}
            <div className="flex items-center gap-2 lg:hidden">
              {/* Mobile Language Trigger */}
              <button
                id="mobile-language-toggle"
                onClick={toggleLanguage}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 border border-slate-705 text-[11px] font-bold text-slate-200 hover:bg-slate-750"
              >
                <Languages className="w-3.5 h-3.5 text-brand-secondary" />
                <span>{lang === 'en' ? 'বাংলা' : 'EN'}</span>
              </button>

              <button
                id="mobile-menu-hamburger"
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none transition-colors border border-slate-850"
                aria-label="Toggle navigation menu"
              >
                {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        <div
          id="mobile-nav-panel"
          className={`lg:hidden fixed inset-0 top-[72px] sm:top-[112px] z-30 transform transition-transform duration-300 ease-in-out bg-slate-950/98 backdrop-blur-lg ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="px-4 pt-4 pb-6 space-y-2 border-t border-slate-850 shadow-inner">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-widest px-3 mb-2 flex justify-between items-center">
              <span>{lang === 'en' ? 'School Navigation' : 'স্কুল নেভিগেশন'}</span>
              <button
                onClick={toggleLanguage}
                className="text-[10px] text-brand-secondary uppercase font-extrabold flex items-center gap-1 px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-md"
              >
                <Languages className="w-3 h-3 text-brand-secondary" />
                <span>{lang === 'en' ? 'বাংলা ভাষাতে সুইচ করুন' : 'Switch to English'}</span>
              </button>
            </div>
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full text-left px-4 py-3.5 rounded-xl text-base font-medium transition-all duration-200 flex items-center justify-between ${
                    isActive
                      ? 'bg-slate-900 border-l-4 border-brand-secondary text-brand-secondary'
                      : 'text-slate-300 hover:bg-slate-900/50 hover:text-white border-l-4 border-transparent'
                  }`}
                >
                  <span>{item.label}</span>
                  <span className="text-slate-600 text-xs">→</span>
                </button>
              );
            })}

            <div className="pt-6 border-t border-slate-850 mt-4 px-3 space-y-4">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-widest">
                {lang === 'en' ? 'Immediate Contacts' : 'জরুরী যোগাযোগ'}
              </div>
              <div className="grid grid-cols-1 gap-2 text-xs text-slate-400">
                <a href={`tel:${CORE_INFO.contacts.hotline}`} className="flex items-center gap-2.5 p-2 bg-slate-900/40 rounded-lg hover:text-white">
                  <Phone className="w-4 h-4 text-brand-secondary" />
                  <span>{lang === 'en' ? 'Admissions' : 'ভর্তি শাখা'}: {CORE_INFO.contacts.hotline}</span>
                </a>
                <a href={`mailto:${CORE_INFO.contacts.email}`} className="flex items-center gap-2.5 p-2 bg-slate-900/40 rounded-lg hover:text-white">
                  <Mail className="w-4 h-4 text-brand-secondary" />
                  <span>Email: {CORE_INFO.contacts.email}</span>
                </a>
              </div>

              <button
                id="mobile-apply-cta"
                onClick={() => handleNavClick('admissions')}
                className="w-full bg-gradient-to-r from-brand-secondary to-blue-600 text-slate-950 py-3.5 rounded-xl font-display font-semibold transition-all duration-300 text-center text-sm shadow-md cursor-pointer uppercase tracking-wider"
              >
                {lang === 'en' ? 'Start Admission Inquiry' : 'ভর্তির জন্য আবেদন করুন'}
              </button>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

