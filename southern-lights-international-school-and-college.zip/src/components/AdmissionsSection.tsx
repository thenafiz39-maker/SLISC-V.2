import React, { useState } from 'react';
import { ADMISSION_GRADES, CORE_INFO } from '../data';
import { AdmissionGradeInfo, InquiryFormData } from '../types';
import { ClipboardList, BookOpen, Clock, Layers, HelpCircle, CheckCircle, Send, HeartHandshake, User, Mail, Phone, MapPin, UserCheck } from 'lucide-react';
import { TRANSLATIONS } from '../translations';

interface AdmissionsSectionProps {
  lang: 'en' | 'bn';
}

export default function AdmissionsSection({ lang }: AdmissionsSectionProps) {
  const t = TRANSLATIONS[lang];

  // Calculator Grade selection state
  const [selectedGradeIdx, setSelectedGradeIdx] = useState<number>(2); // Default to Junior School
  const currentGradeInfo = ADMISSION_GRADES[selectedGradeIdx];

  // Default Student Presets for easy testing & fulfilling absolute default rules
  const STUDENT_PRESETS = [
    {
      name: "Nafiz Iqbal",
      parent: "Md. Iqbal Hossain",
      email: "nafiziqbal@example.com",
      phone: "+8801842754722",
      dob: "2011-06-12",
      grade: ADMISSION_GRADES[4].grade, // O Level
      school: "SLISC Junior Campus",
      message: "Highly motivated student, seeking to secure high-tier results under the Pearson Edexcel curriculum."
    },
    {
      name: "Olliur Rahman Abir",
      parent: "Mr. Atiqur Rahman",
      email: "olliur.abir@example.com",
      phone: "+8801711098765",
      dob: "2010-09-25",
      grade: ADMISSION_GRADES[5].grade, // A Level
      school: "Chittagong High School",
      message: "Inquiring about advanced lab schedules, library memberships, and student debate clubs."
    },
    {
      name: "MD. Anas",
      parent: "Dr. Shahidul Anas",
      email: "anas.md@example.com",
      phone: "+8801824332115",
      dob: "2015-02-08",
      grade: ADMISSION_GRADES[2].grade, // Junior School Class 1-5
      school: "Panchlaish Montessori School",
      message: "Admissions inquiry regarding school AC transport routes near Parkview Hospital."
    }
  ];

  // Set the default student name to "Nafiz Iqbal" initially!
  const [formData, setFormData] = useState<InquiryFormData>({
    studentName: STUDENT_PRESETS[0].name,
    dateOfBirth: STUDENT_PRESETS[0].dob,
    gradeInterest: STUDENT_PRESETS[0].grade,
    parentName: STUDENT_PRESETS[0].parent,
    email: STUDENT_PRESETS[0].email,
    phone: STUDENT_PRESETS[0].phone,
    address: 'Panchlaish Residential Area, Chottogram',
    message: STUDENT_PRESETS[0].message,
    previousSchool: STUDENT_PRESETS[0].school
  });

  const [errors, setErrors] = useState<Partial<Record<keyof InquiryFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Roadmap details state
  const [activeStep, setActiveStep] = useState<number>(0);
  
  const admissionSteps = lang === 'en' ? [
    {
      title: "1. Step-1: Inquiry Submission",
      detail: "Submit our simple online inquiry form or visit the SLISC helpdesk near Parkview Hospital. Receive information booklet detailing Edexcel O/A levels / National curriculum English version guides.",
      requiredDoc: "None (Basic contact info only)"
    },
    {
      title: "2. Step-2: Documents Audit",
      detail: "Bring candidate documents for verification to our registration department in the administrative office.",
      requiredDoc: "Candidate's Birth Certificate (Registered), 3 passport photos, father and mother's NID photocopy, academic transcripts of previous school (if applicable)."
    },
    {
      title: "3. Step-3: School Readiness Test",
      detail: "A friendly, age-appropriate readiness evaluation focusing on English proficiency, arithmetic basics, and general sensory coordination (for pre-primaries).",
      requiredDoc: "Admit Card issued by the SLISC Registry Desk during document clearance."
    },
    {
      title: "4. Step-4: Seat Securement",
      detail: "Upon validation of results, secure student ledger, finalize fee deposits, configure student portal keys and collect the uniforms.",
      requiredDoc: "Bank deposit slip, signed declaration policy of Southern Lights International School and College."
    }
  ] : [
    {
      title: "১. ধাপ-১: আবেদনপত্র জমা",
      detail: "আমাদের সহজ অনলাইন অনুসন্ধান ফর্মটি পূরণ করুন অথবা পার্কভিউ হাসপাতালের কাছে SLISC চত্বরে সরাসরি যোগাযোগ করুন। এডেক্সেল ও/এ লেভেল / ইংলিশ ভার্সন বিবরণী সহ তথ্য নির্দেশিকা সংগ্রহ করুন।",
      requiredDoc: "প্রয়োজন নেই (প্রাথমিক তথ্য বিবরণী)"
    },
    {
      title: "২. ধাপ-২: নথিপত্র যাচাইকরণ",
      detail: "পরীক্ষার জন্য আবেদনকারীর সকল শিক্ষাগত ও ব্যক্তিগত নথিপত্র প্রশাসনিক কার্যালয়ের নিবন্ধন বিভাগে জমা দিন।",
      requiredDoc: "আবেদনকারীর জন্ম নিবন্ধন সনদ (অনলাইন কপি), ৩ কপি পাসপোর্ট সাইজ ছবি, পিতামাতার জাতীয় পরিচয়পত্রের ফটোকপি এবং পূর্ববর্তী স্কুলের ছাড়পত্র (প্রযোজ্য ক্ষেত্রে)।"
    },
    {
      title: "৩. ধাপ-৩: স্কুল প্রস্তুতি মূল্যায়ন",
      detail: "ইংরেজি দক্ষতা, প্রাথমিক গণিত শিক্ষা এবং শারীরিক ও সামাজিক সমন্বয় (প্রাক-প্রাথমিক স্তরের জন্য) যাচাইয়ের একটি আনন্দঘন পরীক্ষা।",
      requiredDoc: "নথিপত্র যাচাইয়ের পর SLISC রেজিস্ট্রেশন শাখা থেকে ইস্যুকৃত প্রবেশপত্র।"
    },
    {
      title: "৪. ধাপ-৪: আসন নিশ্চিতকরণ ও ভর্তি",
      detail: "সফলতা অর্জনের পর আসন নিশ্চিত করতে স্কুলের পাওনাদি পরিশোধ করুন, স্টুডেন্ট পোর্টাল সচল করুন এবং গণবেশ (ইউনিফর্ম) সংগ্রহ করুন।",
      requiredDoc: "ব্যাংক জমার রসিদ এবং সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুলের ভর্তি প্রতিশ্রুতি পত্রে স্বাক্ষর।"
    }
  ];

  // Handle active preset profile load
  const loadPreset = (preset: typeof STUDENT_PRESETS[0]) => {
    setFormData({
      studentName: preset.name,
      dateOfBirth: preset.dob,
      gradeInterest: preset.grade,
      parentName: preset.parent,
      email: preset.email,
      phone: preset.phone,
      address: 'Panchlaish Residential Area, Chottogram',
      message: preset.message,
      previousSchool: preset.school
    });
    setErrors({});
  };

  // Handle inquiry calculations mapping
  const handleGradeSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const idx = parseInt(e.target.value);
    setSelectedGradeIdx(idx);
    setFormData(prev => ({ ...prev, gradeInterest: ADMISSION_GRADES[idx].grade }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear validation error on type
    if (errors[name as keyof InquiryFormData]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const tempErrors: Partial<Record<keyof InquiryFormData, string>> = {};
    if (!formData.studentName.trim()) tempErrors.studentName = lang === 'en' ? "Student name is required." : "শিক্ষার্থীর নাম আবশ্যিক।";
    if (!formData.dateOfBirth) tempErrors.dateOfBirth = lang === 'en' ? "Date of birth is required." : "জন্ম তারিখ আবশ্যিক।";
    if (!formData.parentName.trim()) tempErrors.parentName = lang === 'en' ? "Parent name is required." : "পিতামাতার নাম আবশ্যিক।";
    if (!formData.phone.trim()) {
      tempErrors.phone = lang === 'en' ? "Phone number is required." : "যোগাযোগ নম্বর আবশ্যিক।";
    } else if (!/^[0-9+-\s]{7,15}$/.test(formData.phone)) {
      tempErrors.phone = lang === 'en' ? "Provide a valid contact number." : "সঠিক মোবাইল নম্বর প্রদান করুন।";
    }
    if (!formData.email.trim()) {
      tempErrors.email = lang === 'en' ? "Email address is required." : "ইমেইল ঠিকানা আবশ্যিক।";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      tempErrors.email = lang === 'en' ? "Invalid email format." : "অকার্যকর ইমেইল ফরম্যাট।";
    }
    
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    // Simulate API delay
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);

      // Construct and trigger the auto mailto link with all filled-in details
      const emailTo = "slisc.ctg@gmail.com";
      const emailSubject = `[SLISC Admissions Inquiry] - ${formData.studentName} (${formData.gradeInterest})`;
      const emailBody = `Respected SLISC Admissions Office,

I would like to submit an official admissions inquiry for my child/guardian. The compiled dossier details are below:

---------------------------------------------------------
STUDENT PROFILE
---------------------------------------------------------
Full Name: ${formData.studentName}
Date of Birth: ${formData.dateOfBirth}
Grade Level Applied: ${formData.gradeInterest}
Previous Educational Institute: ${formData.previousSchool || 'None / Not Applicable'}

---------------------------------------------------------
SPONSOR / PARENT / GUARDIAN DETAILS
---------------------------------------------------------
Parent/Guardian Name: ${formData.parentName}
Mobile Number / Phone: ${formData.phone}
Contact Email: ${formData.email}
Address: ${formData.address || 'Panchlaish Area, Chattogram'}

---------------------------------------------------------
ACCOUNTS / ADDITIONAL QUERIES / HEALTH CONSTRAINTS
---------------------------------------------------------
${formData.message || 'No additional queries or constraints provided.'}

---------------------------------------------------------
Generated automatically via Southern Lights International School and College (SLISC) Admissions Portal.
Thank you for your assistance.

Warm Regards,
${formData.parentName}
Email: ${formData.email}
Phone: ${formData.phone}`;

      const mailtoUrl = `mailto:${encodeURIComponent(emailTo)}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      
      // Auto-launch the email client
      window.location.href = mailtoUrl;

    }, 1200);
  };

  const resetInquiryForm = () => {
    setFormData({
      studentName: STUDENT_PRESETS[0].name,
      dateOfBirth: STUDENT_PRESETS[0].dob,
      gradeInterest: STUDENT_PRESETS[0].grade,
      parentName: STUDENT_PRESETS[0].parent,
      email: STUDENT_PRESETS[0].email,
      phone: STUDENT_PRESETS[0].phone,
      address: 'Panchlaish Residential Area, Chottogram',
      message: STUDENT_PRESETS[0].message,
      previousSchool: STUDENT_PRESETS[0].school
    });
    setSubmitSuccess(false);
  };

  return (
    <section id="admissions-component-root" className="py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-700 text-xs uppercase font-extrabold rounded-full tracking-widest mb-3 shadow-xs">
            <ClipboardList className="w-3.5 h-3.5" />
            {t.admissionBadge}
          </div>
          <h2 className="text-3.5xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
            {t.admissionTitle}
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-650 leading-relaxed font-normal">
            {t.admissionSub}
          </p>
        </div>

        {/* 2-Column Admission Core */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* LEFT: STEP ROADMAP & DYNAMIC EVALUATOR (7 Columns) */}
          <div className="lg:col-span-7 space-y-12">
            
            {/* Step-by-Step Roadmap */}
            <div id="admissions-roadmap" className="bg-slate-55/65 rounded-3xl p-6 sm:p-8 border border-slate-150">
              <h3 className="font-display font-extrabold text-lg sm:text-xl text-slate-900 mb-6 flex items-center gap-2">
                <span className="p-1.5 bg-sky-100 text-brand-secondary rounded-lg"><Layers className="w-5 h-5" /></span>
                {t.admissionRoadmapTitle}
              </h3>
              
              {/* Stepper Header Pills */}
              <div className="grid grid-cols-4 gap-1.5 mb-6">
                {admissionSteps.map((step, idx) => (
                  <button
                    key={idx}
                    id={`roadmap-step-pill-${idx}`}
                    onClick={() => setActiveStep(idx)}
                    className={`py-2 rounded-lg text-center text-xs font-bold uppercase transition-all duration-300 cursor-pointer ${
                      activeStep === idx
                        ? 'bg-slate-900 text-brand-secondary border-b-2 border-brand-secondary shadow-md'
                        : 'bg-white hover:bg-slate-100/80 text-slate-500 border border-slate-200'
                    }`}
                  >
                    {lang === 'en' ? `Step ${idx + 1}` : `ধাপ ${idx + 1}`}
                  </button>
                ))}
              </div>

              {/* Stepper Active Detail Card */}
              <div id="roadmap-step-detail-card" className="bg-white rounded-2xl p-5 border border-slate-150 min-h-36 shadow-xs animate-fade-in font-sans">
                <h4 className="font-display font-bold text-slate-950 text-base">
                  {admissionSteps[activeStep].title}
                </h4>
                <p className="text-slate-650 text-xs sm:text-sm mt-2.5 leading-relaxed font-normal">
                  {admissionSteps[activeStep].detail}
                </p>
                
                {/* Required Documents Callout */}
                <div className="mt-4 pt-3.5 border-t border-slate-100 text-xs">
                  <span className="font-bold text-slate-950 block mb-1">
                    {lang === 'en' ? 'Required Papers/Actions:' : 'প্রয়োজনীয় নথি/পদক্ষেপ:'}
                  </span>
                  <p className="text-slate-500 italic leading-relaxed">
                    {admissionSteps[activeStep].requiredDoc}
                  </p>
                </div>
              </div>
            </div>

            {/* DYNAMIC GRADE & TUITION ESTIMATOR */}
            <div id="grade-calculator" className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl">
              {/* Subtle background aurora gradient glow */}
              <div className="absolute -top-32 -left-32 w-64 h-64 bg-cyan-500/20 rounded-full light-glow"></div>
              
              <div className="relative z-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h3 className="font-display font-bold text-lg sm:text-xl text-white flex items-center gap-2">
                      <span className="p-1.5 bg-slate-800 text-brand-secondary rounded-lg">
                        <BookOpen className="w-5 h-5" />
                      </span>
                      {t.admissionCalcTitle}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">{t.admissionCalcSub}</p>
                  </div>

                  {/* Dropdown selector */}
                  <div className="relative">
                    <select
                      id="calculator-grade-dropdown"
                      value={selectedGradeIdx}
                      onChange={handleGradeSelectChange}
                      className="bg-slate-800 text-white border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-secondary cursor-pointer"
                    >
                      {ADMISSION_GRADES.map((g, idx) => (
                        <option key={idx} value={idx}>{g.grade}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Info Fields Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Curriculum */}
                  <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 flex gap-3 h-full">
                    <Layers className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'Accredited Scheme' : 'কারিকুলাম স্কিম'}
                      </span>
                      <p className="text-sm font-semibold text-slate-100 mt-1">{currentGradeInfo.curriculum}</p>
                    </div>
                  </div>

                  {/* Age Group */}
                  <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 flex gap-3 h-full">
                    <User className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'Recommended Age Limits' : 'প্রস্তাবিত বয়সসীমা'}
                      </span>
                      <p className="text-sm font-semibold text-slate-100 mt-1">{currentGradeInfo.ageGroup}</p>
                    </div>
                  </div>

                  {/* Class Timings */}
                  <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 flex gap-3 h-full">
                    <Clock className="w-5 h-5 text-brand-secondary shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'School Hours' : 'ক্লাস টাইম'}
                      </span>
                      <p className="text-sm font-semibold text-slate-100 mt-1">{currentGradeInfo.classTimings}</p>
                    </div>
                  </div>

                  {/* Monthly Tuition Estimates */}
                  <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 flex gap-3 h-full">
                    <span className="font-display font-extrabold text-lg text-brand-accent shrink-0 mt-0.5">৳</span>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block">
                        {lang === 'en' ? 'Tuition Cost (Approx)' : 'আনুমানিক মাসিক বেতন'}
                      </span>
                      <p className="text-sm font-display font-bold text-brand-accent mt-1">
                        {lang === 'en' ? currentGradeInfo.feesEstimation : currentGradeInfo.feesEstimation.replace('BDT / month', 'টাকা / মাস')}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Dynamic Subject Tags */}
                <div className="grid-cols-1 mt-5 p-4 bg-slate-800/20 border border-slate-800 rounded-2xl">
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block mb-2.5">
                    {lang === 'en' ? 'Key Curriculum Focus & Subjects' : 'প্রধান পাঠ্যক্রম এবং বিষয়সমূহ'}:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {currentGradeInfo.subjects.map((sub, idx) => (
                      <span
                        key={idx}
                        className="text-xs bg-slate-800 text-slate-300 font-medium px-2.5 py-1 rounded-md border border-slate-750"
                      >
                        {sub}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Security Landmark Callout */}
                <p className="text-[11px] text-slate-500 font-normal leading-relaxed mt-4 italic text-center">
                  {lang === 'en' 
                    ? '* Note: Real fees can scale slightly based on specialized transportation packages in Chottogram or additional labs. Talk with SLISC registrar desk near Parkview Hospital.'
                    : '* দ্রষ্টব্য: চট্টগ্রামে বিশেষায়িত শীতাতপ নিয়ন্ত্রিত পরিবহন বা বিজ্ঞানাগার ব্যবহারের উপর ভিত্তি করে বেতন সামান্য পরিবর্তিত হতে পারে। পার্কভিউ হাসপাতালের পাশে অবস্থিত SLISC কার্যালয়ে কথা বলুন।'}
                </p>
              </div>
            </div>

          </div>

          {/* RIGHT: ONLINE INQUIRY FORM (5 Columns) */}
          <div id="admission-online-inquiry-box" className="lg:col-span-5">
            <div className="bg-slate-50 border border-slate-150 rounded-3xl p-5 sm:p-7 shadow-sm">
              <h3 className="font-display font-extrabold text-lg sm:text-xl text-slate-900 mb-2">
                {t.admissionFormTitle}
              </h3>
              <p className="text-xs text-slate-500 mb-5 font-normal leading-relaxed">
                {t.admissionFormSub}
              </p>

              {/* QUICK DEMO STUDENT PRESETS BADGES CONTAINER */}
              <div className="mb-6 p-3 bg-slate-100 border border-slate-200 rounded-2xl">
                <span className="text-[10px] font-bold text-slate-600 block mb-2 uppercase tracking-wide flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-brand-secondary" />
                  {lang === 'en' ? 'Quick Autofill Student Profiles:' : 'শিক্ষার্থীর প্রোফাইল নির্বাচন (অটোফিল):'}
                </span>
                <div className="flex flex-col gap-1.5">
                  {STUDENT_PRESETS.map((p, idx) => {
                    const isSelected = formData.studentName === p.name;
                    return (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => loadPreset(p)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold text-left transition-all flex justify-between items-center select-none cursor-pointer border ${
                          isSelected
                            ? 'bg-slate-900 border-slate-950 text-brand-secondary shadow-xs scale-[1.01]'
                            : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        <span className="flex items-center gap-1.5">
                          <span className={`w-2.5 h-2.5 rounded-full ${isSelected ? 'bg-brand-secondary' : 'bg-slate-300'}`}></span>
                          <span>{p.name}</span>
                        </span>
                        <span className="text-[9px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 border border-slate-200 group-hover:bg-slate-200 select-none">
                          {p.name === "Nafiz Iqbal" ? "O Level" : p.name === "Olliur Rahman Abir" ? "A Level" : "Class 1-5"}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {submitSuccess ? (
                /* Card Success Badge State */
                <div className="text-center py-10 px-4 bg-white rounded-2xl border border-slate-100 shadow-xs animate-scale-in">
                  <div className="w-14 h-14 bg-emerald-50 text-emerald-650 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-100">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h4 className="font-display font-extrabold text-[#111827] text-lg">
                    {lang === 'en' ? 'Inquiry Confirmed Successfully!' : 'অনুসন্ধান সফলভাবে নিশ্চিত হয়েছে!'}
                  </h4>
                  <p className="text-xs text-slate-500 mt-2.5 leading-relaxed max-w-sm mx-auto">
                    {lang === 'en' ? (
                      <>Thank you for applying to <strong>Southern Lights International School and College</strong>. We have initialized dossier number <strong>SLISC-{Math.floor(1000 + Math.random() * 9000)}-2026</strong> for student <strong>{formData.studentName}</strong>.</>
                    ) : (
                      <><strong>সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ</strong>-এ আবেদন করার জন্য ধন্যবাদ। আমরা শিক্ষার্থী <strong>{formData.studentName}</strong> এর জন্য ডসিয়ার নম্বর <strong>SLISC-{Math.floor(1000 + Math.random() * 9000)}-২০২৬</strong> তৈরি করেছি।</>
                    )}
                  </p>
                  <div className="bg-slate-50 text-[11px] text-slate-650 p-3.5 my-5 rounded-xl border border-slate-150 text-left space-y-1 bg-slate-55">
                    <p><strong className="text-slate-800">{lang === 'en' ? 'Student Name' : 'শিক্ষার্থীর নাম'}:</strong> {formData.studentName}</p>
                    <p><strong className="text-slate-800">{lang === 'en' ? 'Grade Required' : 'শ্রেণী কোটা'}:</strong> {formData.gradeInterest}</p>
                    <p><strong className="text-slate-800">{lang === 'en' ? 'Registered Email' : 'অভিভাবকের ইমেইল'}:</strong> {formData.email}</p>
                    <p><strong className="text-slate-800">{lang === 'en' ? 'Phone' : 'যোগাযোগ নম্বর'}:</strong> {formData.phone}</p>
                  </div>
                  <button
                    onClick={resetInquiryForm}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs py-2.5 px-6 rounded-lg uppercase tracking-wider transition-all duration-200 cursor-pointer"
                  >
                    {lang === 'en' ? 'Submit New Inquiry' : 'নতুন আবেদনপত্র জমা দিন'}
                  </button>
                </div>
              ) : (
                /* Actual Form Formats */
                <form id="online-inquiry-admissions-form" onSubmit={handleFormSubmit} className="space-y-4">
                  
                  {/* Student Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'en' ? "Student's Full Name *" : "শিক্ষার্থীর পূর্ণ নাম *"}
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        name="studentName"
                        value={formData.studentName}
                        onChange={handleInputChange}
                        placeholder="e.g. Adib Chowdhury"
                        className={`w-full bg-white text-slate-900 border ${errors.studentName ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-350'} rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium`}
                      />
                    </div>
                    {errors.studentName && <span className="text-[10px] text-red-500 font-semibold block mt-1">{errors.studentName}</span>}
                  </div>

                  {/* DOB and Grade Flex */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* DOB */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        {lang === 'en' ? 'Date of Birth *' : 'জন্ম তারিখ *'}
                      </label>
                      <input
                        type="date"
                        name="dateOfBirth"
                        value={formData.dateOfBirth}
                        onChange={handleInputChange}
                        className={`w-full bg-white text-slate-900 border ${errors.dateOfBirth ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-350'} rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium`}
                      />
                      {errors.dateOfBirth && <span className="text-[10px] text-red-500 font-semibold block mt-1">{errors.dateOfBirth}</span>}
                    </div>

                    {/* Grade Interest */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        {lang === 'en' ? 'Grade Applied *' : 'কাঙ্ক্ষিত শ্রেণী *'}
                      </label>
                      <select
                        name="gradeInterest"
                        value={formData.gradeInterest}
                        onChange={handleInputChange}
                        className="w-full bg-white text-slate-900 border border-slate-350 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium cursor-pointer"
                      >
                        {ADMISSION_GRADES.map((g, idx) => (
                          <option key={idx} value={g.grade}>{g.grade}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Parent Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'en' ? "Parent's / Guardian's Name *" : "অভিভাবক / পিতা-মাতার নাম *"}
                    </label>
                    <input
                      type="text"
                      name="parentName"
                      value={formData.parentName}
                      onChange={handleInputChange}
                      placeholder="e.g. Mr./Mrs. Chowdhury"
                      className={`w-full bg-white text-slate-900 border ${errors.parentName ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-350'} rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium`}
                    />
                    {errors.parentName && <span className="text-[10px] text-red-500 font-semibold block mt-1">{errors.parentName}</span>}
                  </div>

                  {/* Phone & Email Flex */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Phone */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        {lang === 'en' ? 'Mobile Number *' : 'মোবাইল নম্বর *'}
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="+880 17..."
                        className={`w-full bg-white text-slate-900 border ${errors.phone ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-350'} rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium`}
                      />
                      {errors.phone && <span className="text-[10px] text-red-500 font-semibold block mt-1">{errors.phone}</span>}
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        {lang === 'en' ? 'Email Address *' : 'ইমেইল ঠিকানা *'}
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="parent@example.com"
                        className={`w-full bg-white text-slate-900 border ${errors.email ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-350'} rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium`}
                      />
                      {errors.email && <span className="text-[10px] text-red-500 font-semibold block mt-1">{errors.email}</span>}
                    </div>
                  </div>

                  {/* Previous school */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'en' ? 'Previous Educational Institute (Optional)' : 'পূর্বে অধ্যায়নরত প্রতিষ্ঠান (ঐচ্ছিক)'}
                    </label>
                    <input
                      type="text"
                      name="previousSchool"
                      value={formData.previousSchool}
                      onChange={handleInputChange}
                      placeholder="e.g. Grammar School, Chottogram"
                      className="w-full bg-white text-slate-900 border border-slate-350 rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium"
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'en' ? 'Additional Queries or Health Constraints' : 'অতিরিক্ত জিজ্ঞাসা বা শিক্ষার্থীর শারীরিক সমস্যা'}
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows={3}
                      placeholder={lang === 'en' ? "Let us know your queries." : "আপনার প্রশ্নসমূহ এখানে লিখতে পারেন।"}
                      className="w-full bg-white text-slate-900 border border-slate-350 rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-secondary font-medium resize-none"
                    ></textarea>
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    id="submit-inquiry-button"
                    disabled={isSubmitting}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-brand-secondary py-3.5 rounded-xl font-display font-semibold transition-all duration-300 text-center text-sm shadow-md cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4.5 h-4.5 border-2 border-slate-900 border-t-white rounded-full animate-spin"></span>
                        <span>{lang === 'en' ? 'Encrypting Inquiry...' : 'জমাদান প্রক্রিয়া চলছে...'}</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-brand-secondary" />
                        <span className="text-white">
                          {lang === 'en' ? 'Submit Admissions Dossier' : 'তথ্য বিবরণী আবেদন জমা দিন'}
                        </span>
                      </>
                    )}
                  </button>

                  {/* Secure assurance badge */}
                  <div className="flex items-center gap-2 justify-center text-[10px] text-slate-500 pt-1">
                    <HeartHandshake className="w-3.5 h-3.5 text-emerald-650" />
                    <span>
                      {lang === 'en' ? 'Certified secured channels. We never share details.' : 'নিরাপদ ডেটা ট্রান্সমিশন চ্যানেল। কোনো বিবরণ অন্যদের শেয়ার করা হয় না।'}
                    </span>
                  </div>

                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
