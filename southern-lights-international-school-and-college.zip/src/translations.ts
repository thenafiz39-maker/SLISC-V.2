export interface TranslationSet {
  currentLang: string;
  navHome: string;
  navAbout: string;
  navWhyChooseUs: string;
  navAdmissions: string;
  navEvents: string;
  navGallery: string;
  navContact: string;
  
  // Hero Section
  heroBadge: string;
  heroHeadingPre: string;
  heroHeadingAccent: string;
  heroSub: string;
  heroApplyCta: string;
  heroTourCta: string;
  heroRatio: string;
  heroRatioSub: string;
  heroPassRate: string;
  heroPassRateSub: string;
  heroClubs: string;
  heroClubsSub: string;
  heroBooks: string;
  heroBooksSub: string;
  heroLandmarkTitle: string;
  heroLandmarkSub: string;
  
  // Choose Us Section
  chooseUsTitleBadge: string;
  chooseUsTitle: string;
  chooseUsSub: string;
  
  // Admission Section
  admissionBadge: string;
  admissionTitle: string;
  admissionSub: string;
  admissionRoadmapTitle: string;
  admissionCalcTitle: string;
  admissionCalcSub: string;
  admissionCalcDropdownLabel: string;
  admissionFormTitle: string;
  admissionFormSub: string;
  
  // Events Section
  eventsBadge: string;
  eventsTitle: string;
  eventsSub: string;
  eventsTabUpcoming: string;
  eventsTabPast: string;
  eventsDetailButton: string;
  
  // Gallery Section
  galleryBadge: string;
  galleryTitle: string;
  gallerySub: string;
  galleryCategories: {
    all: string;
    classroom: string;
    laboratory: string;
    sports: string;
    cultural: string;
    campus: string;
  };
  galleryFbTitle: string;
  galleryFbSub: string;
  galleryFbCta: string;
  
  // Contact Section
  contactBadge: string;
  contactTitle: string;
  contactSub: string;
  contactDeskTitle: string;
  contactDeskSub: string;
  contactOfficeHours: string;
  contactOfficeHoursTitle: string;
  contactWorkingDays: string;
  contactStreetTitle: string;
  contactStreetSub: string;
  contactSecurityLandmark: string;
  contactRouteGuideTitle: string;
  contactRouteGuideDesc: string;
}

export const TRANSLATIONS: Record<'en' | 'bn', TranslationSet> = {
  en: {
    currentLang: "বাংলা",
    navHome: "Home",
    navAbout: "About SLISC",
    navWhyChooseUs: "Why Choose Us",
    navAdmissions: "Admissions",
    navEvents: "Events",
    navGallery: "Gallery",
    navContact: "Contact Us",
    
    heroBadge: "Admission Season Open · Session 2026-27",
    heroHeadingPre: "Nurturing Global Minds,",
    heroHeadingAccent: "Inspiring Scholastic Futures",
    heroSub: "Welcome to Southern Lights International School and College (SLISC). Strategically located at 12/B Katalgong, Road# 2, Panchlaish, Chattogram. We merge superior Edexcel Pearson with values that unlock student potentials.",
    heroApplyCta: "Inquire Online Now",
    heroTourCta: "Explore Photo Gallery",
    heroRatio: "15:1 Ratio",
    heroRatioSub: "Student-Teacher Ratio",
    heroPassRate: "100%",
    heroPassRateSub: "O/A Level Pass Rate",
    heroClubs: "25+ Clubs",
    heroClubsSub: "Co-curricular Clubs",
    heroBooks: "15,000+ Books",
    heroBooksSub: "Library Catalogs",
    heroLandmarkTitle: "Physical Landmark",
    heroLandmarkSub: "12/B Katalgong, Road# 2, Panchlaish, Chattogram",
    
    chooseUsTitleBadge: "Distinctive Features of SLISC",
    chooseUsTitle: "Why Choose Our Institution?",
    chooseUsSub: "Serving Panchlaish since inception, we ensure high quality benchmarks. Check why Southern Lights is selected by demanding households in Chattogram.",
    
    admissionBadge: "Admissions Phase 2026-27",
    admissionTitle: "Begin Your Child's Bright Journey",
    admissionSub: "Southern Lights International School and College guarantees a transparent, nurturing, and professional admission loop. Explore criteria and estimate curriculum structures.",
    admissionRoadmapTitle: "Admission Path Roadmap",
    admissionCalcTitle: "Grade & Fees Calculator",
    admissionCalcSub: "Check age criteria, subjects, and estimated tuition fees below",
    admissionCalcDropdownLabel: "Choose Grade Level",
    admissionFormTitle: "Online Admissions Desk",
    admissionFormSub: "Fill the child ledger profile details below. Our admissions manager at Panchlaish will contact you within 24 hours.",
    
    eventsBadge: "School Circular & Agendas",
    eventsTitle: "Upcoming Events & Milestones",
    eventsSub: "Synchronize your schedules with our student activity timelines, admission open days, and STEM Olympiads structured in our Chattogram campus.",
    eventsTabUpcoming: "Upcoming Schedules",
    eventsTabPast: "Historic Glances",
    eventsDetailButton: "Details",
    
    galleryBadge: "Milestones & Visual Tour",
    galleryTitle: "Our Vibrant Campus Gallery",
    gallerySub: "Take a look into academic sessions, modern science lab research, and energetic cultural celebrations thriving within SLISC in Chattogram.",
    galleryCategories: {
      all: "All Photos",
      classroom: "Classrooms",
      laboratory: "Science Labs",
      sports: "Sports Athletics",
      cultural: "Cultural Events",
      campus: "Campus Tour"
    },
    galleryFbTitle: "Browse Thousands of Actual School Activity Photos",
    galleryFbSub: "We continually upload snapshots of daily assemblies, science experiments, sports tournament victories, classroom smiles, and field trips. View our official Facebook Photos stream directly for real-time updates.",
    galleryFbCta: "Visit SLISC Facebook Photo Stream",
    
    contactBadge: "Vitals & Campus Blueprint",
    contactTitle: "How to Reach Our Campus",
    contactSub: "Located at 12/B Katalgong, Road# 2, Panchlaish, Chattogram. Securely positioned for absolute safety, convenience, and child reassurance.",
    contactDeskTitle: "SLISC Information Desk",
    contactDeskSub: "Official Landmark Details",
    contactOfficeHours: "Sunday to Thursday: 8:00 AM - 2:30 PM",
    contactOfficeHoursTitle: "Working Hours",
    contactWorkingDays: "Saturday (Inquiry only): 9:00 AM - 1:00 PM",
    contactStreetTitle: "SLISC Street Blueprint",
    contactStreetSub: "Located directly inside Katalgong Road# 2, providing an easily accessible, quiet premium learning campus.",
    contactSecurityLandmark: "High Security Gated Compound",
    contactRouteGuideTitle: "Access Route Guidance",
    contactRouteGuideDesc: "Coming from Panchlaish roundabout, proceed straight towards Katalgong. Turn onto Katalgong Road# 2, where the secure, gated campus of SLISC is situated prominently, ready with valet assistance."
  },
  bn: {
    currentLang: "English",
    navHome: "হোম",
    navAbout: "আমাদের সম্পর্কে",
    navWhyChooseUs: "কেন আমাদের বেছে নেবেন",
    navAdmissions: "ভর্তি তথ্য",
    navEvents: "ইভেন্টসমূহ",
    navGallery: "গ্যালারি",
    navContact: "যোগাযোগ",
    
    heroBadge: "ভর্তি চলছে · শিক্ষাবর্ষ ২০২৬-২৭",
    heroHeadingPre: "মেধার বিশ্বমানের বিকাশ,",
    heroHeadingAccent: "উজ্জ্বল ভবিষ্যতের পথপ্রদর্শক",
    heroSub: "সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ (SLISC)-এ স্বাগতম। আমাদের ক্যাম্পাস চট্টগ্রামের পাঁচলাইশ থানাধীন ১২/বি কাতালগঞ্জ, রোড# ২-এ অত্যন্ত সুরক্ষিত ও মনোরম পরিবেশে অবস্থিত। আমরা পিয়ারসন এডেক্সেল ব্রিটিশ কারিকুলাম এবং জাতীয় কারিকুলাম ইংলিশ ভার্সনের সমন্বয়ে আধুনিক শিক্ষা প্রদান করি।",
    heroApplyCta: "অনলাইনে তথ্য ফরম পূরণ করুন",
    heroTourCta: "ক্যাম্পাস ফটো গ্যালারি দেখুন",
    heroRatio: "অনুপাত ১৫:১",
    heroRatioSub: "শিক্ষক ও শিক্ষার্থীর অনুপাত",
    heroPassRate: "১০০%",
    heroPassRateSub: "ও / এ লেভেল সাফল্যের হার",
    heroClubs: "২৫+ ক্লাব",
    heroClubsSub: "সহপাঠ্যক্রমিক কার্যক্রম",
    heroBooks: "১৫,০০০+ বই",
    heroBooksSub: "আধুনিক লাইব্রেরি ভাণ্ডার",
    heroLandmarkTitle: "ভৌত ল্যান্ডমার্ক",
    heroLandmarkSub: "১২/বি কাতালগঞ্জ, রোড# ২, পাঁচলাইশ, চট্টগ্রাম",
    
    chooseUsTitleBadge: "আমাদের স্কুলের বিশেষ বৈশিষ্ট্যসমূহ",
    chooseUsTitle: "কেন আমাদের স্কুল বেছে নেবেন?",
    chooseUsSub: "প্রতিষ্ঠালগ্ন থেকেই পাঁচলাইশ চট্টগ্রামের অন্যতম শীর্ষ শিক্ষা প্রতিষ্ঠান হিসেবে আমরা শিক্ষার উচ্চমান বজায় রাখছি। কেন চট্টগ্রামের সচেতন অভিভাবকেরা আমাদের ওপর আস্থা রাখেন তা জেনে নিন।",
    
    admissionBadge: "ভর্তি সেশন ২০২৬-২৭",
    admissionTitle: "আপনার সন্তানের উজ্জ্বল ভবিষ্যতের সূচনা",
    admissionSub: "সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ একটি স্বচ্ছ, যত্নশীল এবং অত্যন্ত পেশাদার ভর্তি প্রক্রিয়া নিশ্চিত করে। যোগ্যতা, ফি-এর হিসাব এবং কারিকুলাম নিচে বিস্তারিত দেখুন।",
    admissionRoadmapTitle: "ধাপে ধাপে ভর্তি প্রক্রিয়া",
    admissionCalcTitle: "শ্রেণী এবং বেতন ক্যালকুলেটর",
    admissionCalcSub: "নিচের ড্রপডাউন থেকে আপনার কাঙ্ক্ষিত শ্রেণী বেছে নিয়ে বয়সসীমা, বিষয়সমূহ এবং আনুমানিক মাসিক ফি দেখে নিন",
    admissionCalcDropdownLabel: "শ্রেণী নির্বাচন করুন",
    admissionFormTitle: "অনলাইন ভর্তি তথ্য ডেস্ক",
    admissionFormSub: "নিচের ফর্মে ছাত্র/ছাত্রীর বিবরণ নির্ভুলভাবে পূরণ করুন। চট্টগ্রামের পাঁচলাইশ ক্যাম্পাসের ভর্তি শাখা থেকে ২৪ ঘণ্টার মধ্যে আপনার সাথে যোগাযোগ করা হবে।",
    
    eventsBadge: "স্কুল নোটিশ ও বিজ্ঞপ্তি",
    eventsTitle: "আসন্ন ইভেন্ট ও কার্যক্রম",
    eventsSub: "আমাদের পাঁচলাইশ চট্টগ্রাম ক্যাম্পাসে অনুষ্ঠিত হতে যাওয়া বিজ্ঞান মেলা, ভর্তি উৎসব এবং সাংস্কৃতিক সন্ধ্যার সময়সূচী জেনে নিন।",
    eventsTabUpcoming: "আসন্ন ইভেন্টসমূহ",
    eventsTabPast: "অতীতের সোনালী স্মৃতিকথা",
    eventsDetailButton: "বিস্তারিত দেখুন",
    
    galleryBadge: "ফটোগ্রাফিক ট্যুর ও মাইলফলক",
    galleryTitle: "আমাদের প্রাণবন্ত প্রাঙ্গণের গ্যালারি",
    gallerySub: "চট্টগ্রামের আমাদের নিজস্ব ক্যাম্পাসে শিক্ষার্থীদের চমৎকার ক্লাস পারফর্মেন্স, বিজ্ঞান ল্যাবের পরীক্ষা এবং আনন্দময় সাংস্কৃতিক উৎসবের চিত্র দেখুন।",
    galleryCategories: {
      all: "সকল ছবি",
      classroom: "স্মার্ট ক্লাসরুম",
      laboratory: "বিজ্ঞানাগার",
      sports: "খেলাধুলা ও শরীরচর্চা",
      cultural: "সাংস্কৃতিক অনুষ্ঠান",
      campus: "ক্যাম্পাস ট্যুর"
    },
    galleryFbTitle: "হাজার হাজার বাস্তব স্কুল ক্রিয়াকলাপের ছবি দেখুন",
    galleryFbSub: "আমরা প্রতিনিয়ত আমাদের দৈনিক অ্যাসেম্বলি, বিজ্ঞান ল্যাব, বার্ষিক ক্রীড়া প্রতিযোগিতা এবং আনন্দঘন মুহূর্তের ছবি আপলোড করি। আমাদের অফিশিয়াল ফেসবুক ফটো স্ট্রিম থেকে সরাসরি রিয়েল-টাইম ছবিগুলো দেখতে পারেন।",
    galleryFbCta: "SLISC ফেসবুক ফটো গ্যালারি ভিজিট করুন",
    
    contactBadge: "যোগাযোগ এবং ক্যাম্পাস ম্যাপ",
    contactTitle: "আমাদের ক্যাম্পাসে যেভাবে আসবেন",
    contactSub: "চট্টগ্রামের পাঁচলাইশ থানাধীন ১২/বি কাতালগঞ্জ, রোড# ২-এ অত্যন্ত সুরক্ষিত ও মনোরম পরিবেশে আমাদের ক্যাম্পাস অবস্থিত। এটি চট্টগ্রামের যেকোনো কোণ থেকে সহজেই যাতায়াতযোগ্য।",
    contactDeskTitle: "SLISC তথ্য হেল্পডেস্ক",
    contactDeskSub: "অফিশিয়াল ল্যান্ডমার্ক বিবরণী",
    contactOfficeHours: "রবিবার থেকে বৃহস্পতিবার: সকাল ৮:০০ - দুপুর ২:৩০",
    contactOfficeHoursTitle: "অফিস খোলার সময়",
    contactWorkingDays: "শনিবার (শুধুমাত্র তথ্য ডেস্ক): সকাল ৯:০০ - দুপুর ১:০০",
    contactStreetTitle: "SLISC রোড ম্যাপ",
    contactStreetSub: "চট্টগ্রাম পাঁচলাইশের কাতালগঞ্জ রোড# ২ সংলগ্ন সড়কসমূহের রেখাচিত্র। আমাদের প্রধান গেট চমৎকার ট্রাফিকের সুবিধা দেয়।",
    contactSecurityLandmark: "উচ্চ নিরাপত্তা বলয় বেষ্টিত ও সিসিটিভি নিয়ন্ত্রিত",
    contactRouteGuideTitle: "যাতায়াত নির্দেশিকা",
    contactRouteGuideDesc: "পাঁচলাইশ গোলচত্ত্বর থেকে সোজা কাতালগঞ্জের দিকে এগোবেন এবং কাতালগঞ্জ রোড# ২-এ প্রবেশ করবেন। সেখানে চমৎকার ডিজাইনকৃত সাউদার্ন লাইটস স্কুল এন্ড কলেজের নিজস্ব ক্যাম্পাস গেটটি দেখতে পাবেন। অভিভাবক ও দর্শনার্থীদের জন্য সার্বক্ষণিক গাড়ি পার্কিংয়ের ব্যবস্থা রয়েছে।"
  }
};
