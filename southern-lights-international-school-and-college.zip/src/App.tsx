import React, { useState } from 'react';
import Header from './components/Header';
import GallerySection from './components/GallerySection';
import AdmissionsSection from './components/AdmissionsSection';
import EventsSection from './components/EventsSection';
import LocationMap from './components/LocationMap';
import FAQSection from './components/FAQSection';

import { CORE_INFO, CHOOSE_US_HIGHLIGHTS } from './data';
import { TRANSLATIONS } from './translations';
import { 
  GraduationCap, MapPin, Award, CheckCircle2, TrendingUp, Compass, 
  HelpCircle, ChevronRight, UserCheck, ShieldCheck, Mail, Phone, Clock, 
  BookOpen, Star, HelpCircle as HelpIcon, ArrowUpRight, Code2
} from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [lang, setLang] = useState<'en' | 'bn'>('en');

  // Smooth slide scroll to element anchors
  const handleNavigation = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 110; // offset for sticky header
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const t = TRANSLATIONS[lang];

  return (
    <div id="school-website-root-container" className="bg-slate-50 font-sans min-h-screen selection:bg-brand-secondary selection:text-slate-950 overflow-x-hidden">
      
      {/* Sticky Header Navigation Component */}
      <Header activeSection={activeSection} onNavigate={handleNavigation} lang={lang} setLang={setLang} />

      {/* 1. HERO HOME DASHBOARD SECTION */}
      <section 
        id="home" 
        className="relative bg-slate-950 text-white pt-20 pb-20 sm:pt-28 sm:pb-32 overflow-hidden border-b border-slate-900"
      >
        {/* Deep visual Southern Aurora glowing light backgrounds */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-sky-500/10 rounded-full light-glow"></div>
        <div className="absolute -top-[160px] right-[10%] w-[350px] h-[350px] bg-gradient-to-tr from-cyan-400 to-blue-600 opacity-20 rounded-full light-glow"></div>
        <div className="absolute bottom-[-100px] left-[5%] w-[400px] h-[400px] bg-amber-500/5 rounded-full light-glow"></div>

        {/* Diagonal abstract guidelines lines */}
        <div className="absolute inset-x-0 bottom-0 top-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:32px_32px]"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Main Hero grid split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* L-Grid Hero message */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
              
              {/* Highlight Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 shadow-md">
                <span className="w-2 h-2 rounded-full bg-brand-secondary animate-pulse animate-duration-1000"></span>
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-350">
                  {t.heroBadge}
                </span>
              </div>

              {/* Bold Title */}
              <h1 className="text-4xl sm:text-5xl lg:text-5.5xl font-display font-black tracking-tight leading-none text-white">
                {lang === 'en' ? 'Nurturing Global Minds,' : 'মেধার বিশ্বমানের বিকাশ,'} <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-brand-secondary via-sky-400 to-brand-accent bg-clip-text text-transparent">
                  {lang === 'en' ? 'Inspiring Scholastic Futures' : 'উজ্জ্বল ভবিষ্যতের পথপ্রদর্শক'}
                </span>
              </h1>

              {/* Sub-instructions Location */}
              <p className="text-slate-350 text-sm sm:text-base lg:text-lg leading-relaxed max-w-2xl font-normal">
                {t.heroSub}
              </p>

              {/* Action Buttons Frame */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <button
                  id="hero-enroll-action"
                  onClick={() => handleNavigation('admissions')}
                  className="bg-brand-secondary hover:bg-sky-500 text-slate-950 font-display font-extrabold text-sm py-4 px-8 rounded-xl tracking-wider transition-all duration-300 transform hover:-translate-y-0.5 shadow-lg shadow-cyan-500/20 text-center cursor-pointer uppercase"
                >
                  {t.heroApplyCta}
                </button>
                <button
                  id="hero-tour-action"
                  onClick={() => handleNavigation('gallery')}
                  className="bg-slate-900/80 hover:bg-slate-800 hover:text-white text-slate-300 font-display font-bold text-sm py-4 px-8 rounded-xl tracking-wide transition-all border border-slate-750 text-center cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>{t.heroTourCta}</span>
                  <Compass className="w-4 h-4 text-brand-secondary" />
                </button>
              </div>

              {/* Highlights List checkmarks */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs text-slate-400">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4.5 h-4.5 text-brand-secondary shrink-0" />
                  <span>{lang === 'en' ? 'Pearson Edexcel O/A Levels & English Version' : 'পিয়ারসন এডেক্সেল ও / এ লেভেল এবং ইংলিশ ভার্সন'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4.5 h-4.5 text-brand-secondary shrink-0" />
                  <span>{lang === 'en' ? 'Panchlaish Residential Guard-Patrolled Gated Security' : 'পাঁচলাইশ আবাসিক এলাকায় সুরক্ষিত পুলিশ-প্যাট্রোলড গেটেড নিরাপত্তা'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4.5 h-4.5 text-brand-secondary shrink-0" />
                  <span>{lang === 'en' ? 'Complete A/C Multimedia Smart Classrooms' : 'সম্পূর্ণ শীতাতপ নিয়ন্ত্রিত মাল্টিমিডিয়া স্মার্ট ক্লাসরুম'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4.5 h-4.5 text-brand-secondary shrink-0" />
                  <span>{lang === 'en' ? 'Interactive Science Labs & ICT Center' : 'অত্যাধুনিক ইন্টারেক্টিভ বিজ্ঞান গবেষণাগার ও আইসিটি সেন্টার'}</span>
                </div>
              </div>

            </div>

            {/* R-Grid visual card stack (5 Columns) */}
            <div className="lg:col-span-5 relative mt-8 lg:mt-0">
              
              {/* Outer decorative ring */}
              <div className="absolute -inset-1 bg-gradient-to-tr from-brand-secondary to-brand-accent rounded-3xl blur opacity-15"></div>

              {/* Main aesthetic showcase card */}
              <div className="relative bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
                
                {/* Real-time enrollment widget */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div className="flex gap-2 items-center">
                    <GraduationCap className="w-6 h-6 text-brand-secondary" />
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-black block">{lang === 'en' ? 'Establishment' : 'প্রতিষ্ঠান'}</span>
                      <strong className="text-white font-display text-sm">{lang === 'en' ? 'SLISC Chottogram' : 'SLISC চট্টগ্রাম'}</strong>
                    </div>
                  </div>
                  <span className="bg-emerald-500/10 text-emerald-400 text-[10px] uppercase font-bold border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                    {lang === 'en' ? 'A/C Shuttles' : 'এসি বাস সুবিধা'}
                  </span>
                </div>

                {/* Counter metrics list grids */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-855">
                    <span className="text-2xl sm:text-3.5xl font-display font-black text-brand-secondary">15:1</span>
                    <p className="text-[10px] sm:text-xs text-slate-400 mt-1 font-medium">{t.heroRatio}</p>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-855">
                    <span className="text-2xl sm:text-3.5xl font-display font-black text-brand-secondary">100%</span>
                    <p className="text-[10px] sm:text-xs text-slate-400 mt-1 font-medium">{t.heroPassRateSub}</p>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-855">
                    <span className="text-2xl sm:text-3.5xl font-display font-black text-brand-secondary">25+</span>
                    <p className="text-[10px] sm:text-xs text-slate-400 mt-1 font-medium">{t.heroClubsSub}</p>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-2xl border border-slate-855">
                    <span className="text-2xl sm:text-3.5xl font-display font-black text-brand-secondary">15k+</span>
                    <p className="text-[10px] sm:text-xs text-slate-400 mt-1 font-medium">{t.heroBooksSub}</p>
                  </div>
                </div>

                {/* Local Area Anchor Info Card */}
                <div className="p-4 bg-slate-950/80 border border-slate-850 rounded-2xl flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">{t.heroLandmarkTitle}</span>
                    <p className="text-xs text-slate-200 font-semibold mt-0.5 leading-relaxed">
                      {lang === 'en' ? '12/B Katalgong, Road# 2, Panchlaish, Chattogram.' : '১২/বি কাতালগঞ্জ, রোড# ২, পাঁচলাইশ, চট্টগ্রাম।'}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {lang === 'en' ? '(Convenient Elite Residential Campus)' : '(সুবিধাজনক মনোরম আবাসিক ক্যাম্পাস)'}
                    </p>
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>
      </section>


      {/* 2. ABOUT US: HISTORY, PRINCIPAL VALUES, STAFF */}
      <section id="about" className="py-20 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Main heading */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-sky-50 text-brand-secondary text-xs uppercase font-extrabold rounded-full tracking-wider mb-3 shadow-xs">
              <Award className="w-3.5 h-3.5" />
              {lang === 'en' ? 'SLISC Administration & Core Values' : 'SLISC প্রশাসন ও মূল নীতিসমূহ'}
            </div>
            <h2 className="text-3.5xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
              {lang === 'en' ? 'An Academic Vision Built Upon Integrity' : 'নিষ্ঠার ভিত্তিতে তিল তিল করে গড়ে ওঠা আমাদের একাডেমিক ভিশন'}
            </h2>
            <p className="mt-4 text-base text-slate-550 leading-relaxed font-normal">
              {lang === 'en' 
                ? 'For over a decade, Southern Lights International School and College has empowered young scholars in Chottogram. We build independent thinkers equipped with both classic ethical behavior and digital-first literacy.'
                : 'এক দশকেরও বেশি সময় ধরে, সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ চট্টগ্রামের তরুণ মেধার বিকাশ ঘটিয়ে চলেছে। আমরা স্বাধীন চিন্তাশীল শিক্ষার্থী গড়ে তুলি যারা নৈতিক মূল্যবোধ এবং ডিজিটাল-প্রথম শিক্ষায় স্বয়ংসম্পূর্ণ।'}
            </p>
          </div>

          {/* Vision Blocks Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            
            {/* Value-1 */}
            <div className="p-6 sm:p-8 bg-slate-55 border border-slate-100 rounded-3xl space-y-4 shadow-2xs hover:shadow-md hover:border-slate-300 transition-all duration-300">
              <div className="w-12 h-12 bg-sky-50 text-brand-secondary border border-sky-100 rounded-2xl flex items-center justify-center">
                <Star className="w-6 h-6" />
              </div>
              <h3 className="font-display font-extrabold text-slate-900 text-lg">
                {lang === 'en' ? 'Academic Integrity' : 'একাডেমিক সততা'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-650 leading-relaxed font-normal">
                {lang === 'en'
                  ? 'Rigorous Pearson Edexcel British curriculums vetted for candidate confidence, ensuring O Level/A Level final assessments yield elite A* grades across Chottogram rankings.'
                  : 'কঠোর পিয়ারসন এডেক্সেল ব্রিটিশ কারিকুলাম দ্বারা পরিচালিত শিক্ষা ব্যবস্থা, যা ও লেভেল এবং এ লেভেল পরীক্ষায় চট্টগ্রামের মেধা তালিকায় প্রথম সারির এ* (A*) ফলাফল অর্জনে সাহায্য করে।'}
              </p>
            </div>

            {/* Value-2 */}
            <div className="p-6 sm:p-8 bg-slate-55 border border-slate-100 rounded-3xl space-y-4 shadow-2xs hover:shadow-md hover:border-slate-350 transition-all duration-300">
              <div className="w-12 h-12 bg-amber-50 text-brand-accent border border-amber-100 rounded-2xl flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-display font-extrabold text-slate-900 text-lg">
                {lang === 'en' ? 'Nurturing & Safety' : 'নিরাপত্তা ও পরিচর্যা'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-650 leading-relaxed font-normal">
                {lang === 'en'
                  ? 'Gated campus compound with round-the-clock CCTV, secure student supervision, and a supportive, caring learning environment.'
                  : 'সার্বক্ষণিক সিসিটিভি ক্যামেরা পর্যবেক্ষণ, সুরক্ষিত আবাসিক ক্যাম্প সংলগ্ন পরিবেশ এবং শিক্ষার্থীদের জন্য নিবিড় নিরাপত্তা প্রাঙ্গণ।'}
              </p>
            </div>

            {/* Value-3 */}
            <div className="p-6 sm:p-8 bg-slate-55 border border-slate-100 rounded-3xl space-y-4 shadow-2xs hover:shadow-md hover:border-slate-350 transition-all duration-300">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-2xl flex items-center justify-center">
                <Compass className="w-6 h-6" />
              </div>
              <h3 className="font-display font-extrabold text-slate-900 text-lg">
                {lang === 'en' ? 'Global Stewardship' : 'বিশ্বমানের দৃষ্টিভঙ্গি'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-650 leading-relaxed font-normal">
                {lang === 'en'
                  ? 'Fostering future-ready leadership traits, analytical logic, digital-literacy, and co-curricular prowess across 25+ dynamic clubs.'
                  : 'ভবিষ্যতের নেতৃত্ব গুণ, যৌক্তিক বিশ্লেষণ, ডিজিটাল সক্ষমতা এবং ২৫টিরও বেশি বিভিন্ন ক্লাবের মাধ্যমে সহপাঠ্যক্রমিক প্রতিভা অর্জন।'}
              </p>
            </div>

          </div>

        </div>
      </section>


      {/* 3. WHY CHOOSE SLISC? (FEATURES GRID SECTION) */}
      <section id="features" className="py-20 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Heading */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-700 text-xs uppercase font-extrabold rounded-full tracking-widest mb-3 shadow-xs">
              <Star className="w-3.5 h-3.5" />
              {t.chooseUsTitleBadge}
            </div>
            <h2 className="text-3.5xl sm:text-4xl font-display font-black text-slate-900 tracking-tight">
              {t.chooseUsTitle}
            </h2>
            <p className="mt-4 text-sm sm:text-base text-slate-500 font-normal leading-relaxed">
              {t.chooseUsSub}
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {CHOOSE_US_HIGHLIGHTS.map((item, idx) => (
              <div
                key={item.id}
                id={`feature-card-${item.id}`}
                className="bg-white border border-slate-150 rounded-3xl p-6 sm:p-8 hover:border-slate-350 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative"
              >
                {/* Visual badge numbers */}
                <span className="absolute top-4 right-4 text-5xl font-display font-black text-slate-100 select-none z-0">
                  0{idx + 1}
                </span>

                <div className="relative z-10 space-y-4">
                  {/* Decorative Box icon */}
                  <div className="w-11 h-11 bg-sky-50 text-brand-secondary rounded-xl flex items-center justify-center border border-sky-100 shadow-sm">
                    {item.icon === "GraduationCap" && <GraduationCap className="w-5.5 h-5.5" />}
                    {item.icon === "MapPin" && <MapPin className="w-5.5 h-5.5" />}
                    {item.icon === "FlaskConical" && <BookOpen className="w-5.5 h-5.5" />}
                    {item.icon === "Award" && <Award className="w-5.5 h-5.5" />}
                    {item.icon === "Users" && <UserCheck className="w-5.5 h-5.5" />}
                    {item.icon === "Tv" && <BookOpen className="w-5.5 h-5.5" />}
                  </div>

                  <h3 className="font-display font-extrabold text-[#0f172a] text-lg">
                    {lang === 'en' 
                      ? item.title 
                      : (idx === 0 ? "দ্বিমুখী পাঠ্যক্রম" : idx === 1 ? "নিরাপদ ও সহজে অ্যাক্সেসযোগ্য" : idx === 2 ? "ভবিষ্যত-উপযোগী বিজ্ঞানাগার" : idx === 3 ? "সামগ্রিক শিক্ষার্থীর বিকাশ" : idx === 4 ? "প্রশিক্ষিত শিক্ষক মণ্ডলী" : "শীতাতপ নিয়ন্ত্রিত শ্রেণীকক্ষ")}
                  </h3>
                  
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                    {lang === 'en'
                      ? item.description
                      : (idx === 0 ? "আমরা বিশ্বমানের পিয়ারসন এডেক্সেল (ও ও এ লেভেল) এবং জাতীয় কারিকুলাম ইংলিশ ভার্সন উভয়ের সুযোগ প্রদান করি।" :
                         idx === 1 ? "ক্যামপাসটি সম্পূর্ণ সিসিটিভি নিয়ন্ত্রিত ডাবল-গেট নিরাপত্তা বেষ্টিত গেটের সংলগ্ন শান্ত পাঁচলাইশ আবাসিক ব্লকে।" :
                         idx === 2 ? "তাত্ত্বিক শিক্ষার পাশাপাশি ব্যবহারিক জ্ঞান অর্জনে আধুনিক পদার্থবিজ্ঞান, রসায়ন, জীববিজ্ঞান ও আইসিটি কম্পিউটার বিজ্ঞানাগার রয়েছে।" :
                         idx === 3 ? "পাবলিক স্পিকিং, রোবোটিক্স ওয়ার্কশপ, দাবা ক্লাব, ফুটবল একাডেমি এবং চিত্রাঙ্কনের মাধ্যমে সুপ্ত গুণের সঠিক মূল্যায়ন।" :
                         idx === 4 ? "আন্তর্জাতিক যোগ্যতা সম্পন্ন ও প্রশিক্ষিত শিক্ষক মণ্ডলী, চমৎকার ১৫:১ ছাত্র-শিক্ষক অনুপাতে নিবিড় যত্ন।" :
                         "শিক্ষার্থীদের আরামদায়ক শিক্ষার পরিবেশ নিশ্চিত করতে প্রতিটি মাল্টিমিডিয়ার শ্রেণীকক্ষ সম্পূর্ণ এসি দ্বারা সুসজ্জিত।")}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      
      {/* 4. ADMISSIONS INFOMATION SECTION COMPONENT */}
      <div id="admissions">
        <AdmissionsSection lang={lang} />
      </div>


      {/* 5. DYNAMIC EVENTS TIMELINES */}
      <div id="events">
        <EventsSection lang={lang} />
      </div>


      {/* 6. PICTURE GALLERY FRAME */}
      <div id="gallery">
        <GallerySection lang={lang} />
      </div>


      {/* 7. FAQS DIRECTORY */}
      <div id="faqs">
        <FAQSection lang={lang} />
      </div>


      {/* 8. DIRECTIONS MAP & INFORMATION DESK */}
      <div id="contact">
        <LocationMap lang={lang} />
      </div>


      {/* 9. STUDENT DEVELOPERS CORNER */}
      <section className="bg-slate-900 border-t border-slate-950 py-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-brand-secondary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-slate-850 border border-slate-850 text-slate-350 text-[10px] uppercase tracking-widest font-bold mb-4">
            <Code2 className="w-3.5 h-3.5 text-brand-secondary" />
            {lang === 'en' ? 'Digital creators' : 'ডিজিটাল ক্রিয়েটরস'}
          </div>
          <h3 className="font-display font-black text-white text-lg sm:text-xl tracking-tight mb-2">
            {lang === 'en' ? 'Crafted by the Students of SLISC' : 'আমাদের শিক্ষার্থীদের দ্বারা নির্মিত'}
          </h3>
          <p className="text-xs text-slate-450 max-w-lg mx-auto leading-relaxed mb-6 font-normal">
            {lang === 'en' 
              ? 'This official web portal was designed, styled, and precision-coded by the talented high school students of Southern Lights International School and College: Nafiz Iqbal, Olliur Rahman Abir, MD. Anas.'
              : 'সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজের হাই স্কুল শিক্ষার্থীদের ডিজাইন ও কোড করে তৈরি: নাফিজ ইকবাল, ওলিউর রহমান আবির, মো. আনাস।'}
          </p>
          <div className="flex flex-wrap justify-center items-center gap-4 sm:gap-6">
            {[
              { name: "Nafiz Iqbal", role: lang === 'en' ? "Full-Stack Engineer" : "ফুল-স্ট্যাক প্রকৌশলী", grade: "O Level" },
              { name: "Olliur Rahman Abir", role: lang === 'en' ? "System Architect" : "সিস্টেম আর্কিটেক্ট", grade: "A Level" },
              { name: "MD. Anas", role: lang === 'en' ? "Interface Designer" : "ইন্টারফেস ডিজাইনার", grade: lang === 'en' ? 'Junior School' : 'জুনিয়র স্কুল' }
            ].map((dev, idx) => (
              <div 
                key={idx}
                className="px-5 py-4 bg-slate-950/70 border border-slate-850 rounded-2xl flex items-center gap-4 group text-left min-w-[220px]"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-brand-secondary font-mono text-sm font-bold group-hover:scale-105 transition-transform shrink-0">
                  {dev.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-xs sm:text-sm group-hover:text-brand-secondary transition-colors leading-snug">{dev.name}</h4>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[10px] text-slate-400 font-normal">{dev.role}</span>
                    <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-900 border border-slate-850 text-slate-500 font-bold font-mono uppercase shrink-0">{dev.grade}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* BEAUTIFUL COMPACT FOOTER DESIGN */}
      <footer id="app-footer-brand" className="bg-slate-950 text-slate-400 pt-16 pb-12 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-900 items-start">
            
            {/* L-Grid: School credentials */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-brand-secondary to-brand-accent p-0.5 flex items-center justify-center">
                  <div className="w-full h-full bg-slate-950 rounded-[6px] flex items-center justify-center">
                    <GraduationCap className="w-5.5 h-5.5 text-brand-secondary" />
                  </div>
                </div>
                <span className="font-display font-extrabold text-lg text-white tracking-tight">
                  {lang === 'en' ? 'SLISC CHATTOGRAM' : 'SLISC চট্টগ্রাম'}
                </span>
              </div>
              
              <p className="text-xs text-slate-400 font-normal leading-relaxed max-w-sm">
                {lang === 'en' 
                  ? 'Southern Lights International School and College is an authorized institution located in Panchlaish, Chattogram, providing dual Pearson Edexcel O/A levels and English Version curriculums in a gated, guarded neighborhood.'
                  : 'সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ চট্টগ্রামের পাঁচলাইশ আবাসিক এলাকায় অবস্থিত একটি অনুমোদিত দ্বিমুখী আন্তর্জাতিক পিয়ারসন এডেক্সেল ওএস এবং ইংলিশ ভার্সন স্কুল।'}
              </p>

              {/* Secure badge footer */}
              <div className="text-[11px] text-slate-500 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>
                  {lang === 'en' ? 'Authorized Pearson Edexcel Examination Center' : 'অনুমোদিত পিয়ারসন এডেক্সেল এক্সামিনেশন সেন্টার'}
                </span>
              </div>
            </div>

            {/* M-Grid Links column-1 */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="font-display font-bold text-white text-sm uppercase tracking-wider">
                {lang === 'en' ? 'Quick Navigation' : 'কুইক লিংকসমূহ'}
              </h4>
              <ul className="space-y-2 text-xs">
                <li><button onClick={() => handleNavigation('home')} className="hover:text-white transition-colors cursor-pointer text-left">{t.navHome}</button></li>
                <li><button onClick={() => handleNavigation('about')} className="hover:text-white transition-colors cursor-pointer text-left">{t.navAbout}</button></li>
                <li><button onClick={() => handleNavigation('features')} className="hover:text-white transition-colors cursor-pointer text-left">{t.navWhyChooseUs}</button></li>
                <li><button onClick={() => handleNavigation('admissions')} className="hover:text-white transition-colors cursor-pointer text-left">{t.navAdmissions}</button></li>
                <li><button onClick={() => handleNavigation('events')} className="hover:text-white transition-colors cursor-pointer text-left">{t.navEvents}</button></li>
              </ul>
            </div>

            {/* M-Grid Links column-2 */}
            <div className="md:col-span-4 space-y-3.5">
              <h4 className="font-display font-bold text-white text-sm uppercase tracking-wider">
                {lang === 'en' ? 'Neighborhood Coordinates' : 'ক্যাম্পাস ল্যান্ডমার্ক'}
              </h4>
              
              <div className="space-y-2.5 text-xs">
                <p className="flex gap-2 items-start text-slate-450 leading-relaxed font-normal">
                  <MapPin className="w-4 h-4 text-brand-secondary shrink-0" />
                  <span>
                    {lang === 'en' 
                      ? '12/B Katalgong, Road# 2, Panchlaish, Chattogram, Bangladesh.'
                      : '১২/বি কাতালগঞ্জ, রোড# ২, পাঁচলাইশ, চট্টগ্রাম, বাংলাদেশ।'}
                  </span>
                </p>
                <p className="flex gap-2 items-center text-slate-450">
                  <Phone className="w-4 h-4 text-brand-secondary shrink-0" />
                  <span>{lang === 'en' ? 'Hotline' : 'হটলাইন'}: {CORE_INFO.contacts.hotline}</span>
                </p>
                <p className="flex gap-2 items-center text-slate-450">
                  <Mail className="w-4 h-4 text-brand-secondary shrink-0" />
                  <span>Email: {CORE_INFO.contacts.email}</span>
                </p>
              </div>
            </div>

          </div>

          {/* Bottom attribution copyright rules */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-650">
            <p className="text-center sm:text-left font-normal leading-relaxed">
              © {new Date().getFullYear()} {lang === 'en' ? 'Southern Lights International School and College (SLISC). All Rights Reserved.' : 'সাউদার্ন লাইটস ইন্টারন্যাশনাল স্কুল অ্যান্ড কলেজ (SLISC)। সর্বস্বত্ব সংরক্ষিত।'} 12/B Katalgong, Road# 2, Panchlaish, Chattogram, Bangladesh.
            </p>
            <div className="flex gap-4 items-center">
              <a href="#about" className="hover:text-white transition-colors">{lang === 'en' ? 'Vitals Handbook' : 'তথ্য বিবরণী'}</a>
              <span>·</span>
              <a href="#admissions" className="hover:text-white transition-colors">{lang === 'en' ? 'Privacy & Terms' : 'গোপনীয়তা নীতি'}</a>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}
